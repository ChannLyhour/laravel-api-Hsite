import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { StoreRow } from '@/api/owner/stores';
import { CardProduct } from './CardProduct';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import { FASHION_ROUTES } from '../../routes';

interface ProductBagdeGridProps {
  items: any[];
  ownerUserId?: number | string;
  stores?: StoreRow;
  storeName: string;
  onNavigate?: (to: string) => void;
  addToCart: (item: any, qty?: number, size?: string, color?: string, price?: number) => void;
  favorites: Record<string, boolean>;
  toggleFavorite: (id: string, name: string) => void;
}

interface BadgeSliderRowProps {
  badgeName: string;
  items: any[];
  ownerUserId?: number | string;
  stores?: StoreRow;
  storeName: string;
  onNavigate?: (to: string) => void;
  addToCart: (item: any, qty?: number, size?: string, color?: string, price?: number) => void;
  favorites: Record<string, boolean>;
  toggleFavorite: (id: string, name: string) => void;
}

const getHeaderTextColor = (name: string) => {
  switch (name.toLowerCase()) {
    case 'new':
    case 'new arrival':
      return 'text-emerald-600 dark:text-emerald-400';
    case 'sale':
    case 'discount':
      return 'text-rose-600 dark:text-rose-400';
    case 'trending':
    case 'hot':
      return 'text-amber-600 dark:text-amber-400';
    case 'popular':
    case 'best seller':
      return 'text-violet-600 dark:text-violet-400';
    default:
      return 'text-stone-900 dark:text-stone-100';
  }
};

const BadgeSliderRow: React.FC<BadgeSliderRowProps> = ({
  badgeName,
  items,
  ownerUserId,
  stores,
  storeName,
  onNavigate,
  addToCart,
  favorites,
  toggleFavorite,
}) => {
  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const sliderRef = useRef<HTMLDivElement>(null);

  const handleScroll = () => {
    if (sliderRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = sliderRef.current;
      setShowLeftArrow(scrollLeft > 10);
      setShowRightArrow(scrollLeft + clientWidth < scrollWidth - 10);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const { clientWidth } = sliderRef.current;
      const scrollAmount = direction === 'left' ? -clientWidth * 0.75 : clientWidth * 0.75;
      sliderRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    // Initial check after render and whenever items change
    const timer = setTimeout(() => {
      handleScroll();
    }, 150);
    return () => clearTimeout(timer);
  }, [items]);

  return (
    <div className="space-y-6 w-full text-left">
      {/* Sibling Div 1: Header (Title on Left, SHOP MORE on Right) */}
      <div className="flex items-center justify-between pb-3 border-b border-stone-200/40">
        <h2 className={`text-xs sm:text-sm font-black tracking-widest uppercase font-sans ${getHeaderTextColor(badgeName)}`}>
          {badgeName}
        </h2>
        <a
          href="/shop"
          onClick={(e) => {
            if (onNavigate) {
              e.preventDefault();
              const storeSlug = (stores?.store_name || storeName).replace(/\s+/g, '_');
              onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug));
            }
          }}
          className="text-stone-900 dark:text-stone-100 hover:text-stone-600 dark:hover:text-stone-400 text-[10px] font-black uppercase tracking-widest no-underline transition-colors cursor-pointer"
        >
          Shop More
        </a>
      </div>

      {/* Sibling Div 2: Slider (Cards & Overlaid Navigation Chevrons) */}
      <div className="relative group/slider w-full">
        {/* Navigation Chevron Left */}
        {showLeftArrow && (
          <button
            onClick={() => scroll('left')}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition-all duration-350 shadow z-10 border-none cursor-pointer focus:outline-none opacity-0 group-hover/slider:opacity-100"
          >
            <FiChevronLeft className="w-5 h-5" />
          </button>
        )}

        {/* Navigation Chevron Right */}
        {showRightArrow && (
          <button
            onClick={() => scroll('right')}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition-all duration-350 shadow z-10 border-none cursor-pointer focus:outline-none opacity-0 group-hover/slider:opacity-100"
          >
            <FiChevronRight className="w-5 h-5" />
          </button>
        )}

        {/* Horizontal Slider Scrollable Row */}
        <div
          ref={sliderRef}
          onScroll={handleScroll}
          className="flex space-x-5 overflow-x-auto scrollbar-hide scroll-smooth py-2 w-full"
          style={{
            msOverflowStyle: 'none',
            scrollbarWidth: 'none',
          }}
        >
          {items.map((item, idx) => (
            <div
              key={item.id}
              className="w-[260px] sm:w-[290px] md:w-[305px] shrink-0 animate-fade-in-up"
              style={{ animationDelay: `${idx * 50}ms` }}
            >
              <CardProduct
                item={item}
                ownerUserId={ownerUserId}
                stores={stores}
                storeName={storeName}
                onNavigate={onNavigate}
                addToCart={addToCart}
                isFavorited={!!favorites[String(item.id)]}
                onToggleFavorite={toggleFavorite}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export const ProductBagdeGrid: React.FC<ProductBagdeGridProps> = ({
  items,
  ownerUserId,
  stores,
  storeName,
  onNavigate,
  addToCart,
  favorites,
  toggleFavorite,
}) => {
  // Filter out inactive products
  const activeItems = useMemo(() => {
    return items.filter((item) => {
      if (!item) return false;
      const status = typeof item.status === 'string' ? item.status.toLowerCase() : item.status;
      return (
        status !== false &&
        status !== 'false' &&
        status !== 'inactive' &&
        status !== 'archived' &&
        status !== 'draft'
      );
    });
  }, [items]);

  // Group products dynamically by their badges
  const groupedItems = useMemo(() => {
    const groups: Record<string, any[]> = {};

    activeItems.forEach((item) => {
      let badgeName = '';
      if (item.badge && item.badge.name) {
        // Only group by badge if the badge itself is active
        const bStatus = item.badge.status;
        const isBadgeActive = 
          bStatus !== false && 
          bStatus !== 'false' && 
          bStatus !== 0 && 
          bStatus !== '0' && 
          bStatus !== 'inactive' && 
          bStatus !== 'Inactive';
        
        if (isBadgeActive) {
          badgeName = item.badge.name;
        }
      }
      
      // Fallback: If no active badge, check if item is on sale
      if (!badgeName) {
        const priceVal = parseFloat(item.price) || 0;
        const comparePrice = item.compare_at_price ? parseFloat(item.compare_at_price) : 0;
        if (comparePrice > priceVal) {
          badgeName = 'Sale';
        }
      }

      if (badgeName) {
        if (!groups[badgeName]) {
          groups[badgeName] = [];
        }
        groups[badgeName].push(item);
      }
    });

    return groups;
  }, [activeItems]);

  const badgeKeys = useMemo(() => Object.keys(groupedItems), [groupedItems]);

  if (activeItems.length === 0) {
    return (
      <div className="text-center py-20 space-y-3 border border-dashed border-stone-200 dark:border-stone-850 rounded-[4px] w-full">
        <span className="text-3xl">🧥</span>
        <div>
          <h4 className="font-extrabold text-stone-800 dark:text-stone-200 text-xs uppercase tracking-wider">
            Collection is empty
          </h4>
          <p className="text-stone-400 text-2xs font-semibold mt-1">
            Check back later for newly tagged items!
          </p>
        </div>
      </div>
    );
  }

  // Fallback if no items have specific badges/sale tags - show a general section
  if (badgeKeys.length === 0) {
    return (
      <BadgeSliderRow
        badgeName="Curated Runway"
        items={activeItems}
        ownerUserId={ownerUserId}
        stores={stores}
        storeName={storeName}
        onNavigate={onNavigate}
        addToCart={addToCart}
        favorites={favorites}
        toggleFavorite={toggleFavorite}
      />
    );
  }

  return (
    <div className="space-y-16 sm:space-y-20 w-full">
      {badgeKeys.map((badgeName) => (
        <BadgeSliderRow
          key={badgeName}
          badgeName={badgeName}
          items={groupedItems[badgeName]}
          ownerUserId={ownerUserId}
          stores={stores}
          storeName={storeName}
          onNavigate={onNavigate}
          addToCart={addToCart}
          favorites={favorites}
          toggleFavorite={toggleFavorite}
        />
      ))}
    </div>
  );
};

