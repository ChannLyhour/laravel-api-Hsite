import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { FiX, FiCheck, FiLoader, FiSmartphone } from 'react-icons/fi';
import { toast } from 'react-hot-toast';
import { client } from '@/api/client';

interface PopupPaymentKHQRProps {
     isOpen: boolean;
     onClose: () => void;
     onConfirmPayment: () => void;
     amount: number;
     merchantName?: string;
     currency?: 'USD' | 'KHR';
     orderId: number | string | null;
     paymentMethod?: string;
}

export const PopupPaymentKHQR: React.FC<PopupPaymentKHQRProps> = ({
     isOpen,
     onClose,
     onConfirmPayment,
     amount,
     merchantName = 'Our20s Collection',
     currency = 'USD',
     orderId,
     paymentMethod = 'aba',
}) => {
     const [isVerifying, setIsVerifying] = useState(false);

     // ABA Payment API States
     const [qrString, setQrString] = useState<string | null>(null);
     const [transactionId, setTransactionId] = useState<string | null>(null);
     const [abapayDeeplink, setAbapayDeeplink] = useState<string | null>(null);
     const [isLoadingQr, setIsLoadingQr] = useState(false);
     const [qrError, setQrError] = useState<string | null>(null);

     // Fetch ABA QR Code on Open
     useEffect(() => {
          if (!isOpen || !orderId) {
               setQrString(null);
               setTransactionId(null);
               setAbapayDeeplink(null);
               setQrError(null);
               return;
          }

          const fetchQrCode = async () => {
               setIsLoadingQr(true);
               setQrError(null);
               try {
                    const response = await client.post<any>('/payments/generate-qr', {
                         order_id: Number(orderId),
                         currency: currency,
                    });

                    if (response.success) {
                         setQrString(response.qrString);
                         setTransactionId(response.transaction_id);
                         setAbapayDeeplink(response.abapay_deeplink);
                    } else {
                         setQrError(response.message || 'Failed to generate QR Code');
                         toast.error(response.message || 'Failed to generate QR Code');
                    }
               } catch (err: any) {
                    console.error('Error fetching QR:', err);
                    const errMsg = err.details?.message || err.message || 'Network error occurred';
                    setQrError(errMsg);
                    toast.error(errMsg);
               } finally {
                    setIsLoadingQr(false);
               }
          };

          fetchQrCode();
     }, [isOpen, orderId, currency]);

     // Poll ABA Transaction Status
     useEffect(() => {
          if (!isOpen || !transactionId) return;

          const checkStatus = async () => {
               try {
                    const response = await client.post<any>('/payments/check-transaction', {
                         transaction_id: transactionId,
                    });

                    if (response.success && response.status === 'PAID') {
                         toast.success('Payment Received Successfully!');
                         onConfirmPayment();
                    }
               } catch (err) {
                    console.error('Error checking transaction status:', err);
               }
          };

          const interval = setInterval(checkStatus, 3000); // Check every 3 seconds
          return () => clearInterval(interval);
     }, [isOpen, transactionId, onConfirmPayment]);

     const handleVerify = async () => {
          setIsVerifying(true);
          try {
               // In sandbox/testing mode, we just simulate success after a delay
               await new Promise((resolve) => setTimeout(resolve, 1500));
               toast.success('Sandbox Payment Confirmed!');
               onConfirmPayment();
          } catch (err) {
               toast.error('Verification failed');
          } finally {
               setIsVerifying(false);
          }
     };

     const isBakong = paymentMethod === 'bakong';
     const themeColor = isBakong ? '#b30006' : '#0B3B5B';
     const buttonBg = isBakong ? 'bg-[#b30006] hover:bg-[#8f0005]' : 'bg-[#005D7E] hover:bg-[#004b66]';
     const titleText = isBakong ? 'Bakong KHQR' : 'ABA KHQR';
     const payButtonText = isBakong ? 'Pay in Bakong App' : 'Pay in ABA Mobile';
     const scanInstructionText = isBakong 
          ? 'Scan with Bakong App, or other Mobile Banking App supporting KHQR' 
          : 'Scan with ABA Mobile, or other Mobile Banking App supporting KHQR';

     return createPortal(
          <div className="fixed inset-0 z-[99999] bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 select-none animate-fade-in font-sans">
               <div className="bg-white w-full max-w-[380px] rounded-[5px] shadow-2xl overflow-hidden relative animate-scale-in">
                    {/* Header with Theme Color */}
                    <div 
                         className="px-5 py-4 flex items-center justify-between text-white"
                         style={{ backgroundColor: themeColor }}
                    >
                         <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                                   <FiSmartphone className="w-4.5 h-4.5" />
                              </div>
                              <div>
                                   <h2 className="text-sm font-black tracking-tight leading-none">{titleText}</h2>
                                   <p className="text-[10px] font-bold opacity-70 mt-1 uppercase tracking-wider">Digital Payment</p>
                              </div>
                         </div>
                         <button 
                              onClick={onClose}
                              className="w-8 h-8 rounded-full hover:bg-white/20 flex items-center justify-center transition-colors border-none bg-transparent text-white cursor-pointer"
                         >
                              <FiX className="w-5 h-5" />
                         </button>
                    </div>

                    <div className="p-8 flex flex-col items-center">
                         {/* Ticket Header (Red KHQR tag with diagonal cut) */}
                         <div 
                              className="w-[calc(100%+40px)] bg-[#E61E25] py-3.5 px-4 flex justify-center items-center -mt-5 mb-5 select-none"
                              style={{ clipPath: 'polygon(0 0, 100% 0, 100% 72%, 92% 100%, 0 100%)' }}
                         >
                              <span className="text-white font-sans font-black tracking-[0.2em] text-[15px] flex items-center justify-center">
                                   KHQR
                              </span>
                         </div>

                         {/* Merchant & Amount Info Section */}
                         <div className="w-full text-center space-y-1 mt-1">
                              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest truncate max-w-full">
                                   {merchantName}
                              </p>
                              <div className="flex items-baseline justify-center gap-1.5 mt-2">
                                   <span className="text-3.5xl font-black text-slate-800 tracking-tight leading-none">
                                        {currency === 'USD' ? amount.toFixed(2) : new Intl.NumberFormat('km-KH').format(Math.round(amount * 4100))}
                                   </span>
                                   <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
                                        {currency}
                                   </span>
                              </div>
                         </div>

                         {/* Left and Right Ticket Cutouts and Dashed Separator */}
                         <div className="w-full relative my-5 flex items-center justify-between select-none">
                              <div className="absolute -left-[30px] w-5 h-5 bg-white border border-slate-200/60 rounded-[5px] z-10" />
                              <div className="w-full border-t border-dashed border-slate-300" />
                              <div className="absolute -right-[30px] w-5 h-5 bg-white border border-slate-200/60 rounded-[5px] z-10" />
                         </div>

                         {/* QR Code Container */}
                         <div className="relative w-56 h-56 my-2 flex items-center justify-center bg-white p-2 select-none border border-slate-100 rounded-[5px] shadow-sm">
                              {isLoadingQr ? (
                                   <div className="flex flex-col items-center justify-center text-slate-400 gap-2">
                                        <FiLoader className="w-8 h-8 animate-spin text-[#005D7E]" />
                                        <span className="text-[10px] font-bold tracking-wider uppercase">Generating QR...</span>
                                   </div>
                              ) : qrError ? (
                                   <div className="flex flex-col items-center justify-center text-center p-2 text-red-500 gap-2">
                                        <span className="text-2xl">⚠️</span>
                                        <span className="text-[10px] font-bold leading-tight">{qrError}</span>
                                   </div>
                              ) : qrString ? (
                                   <div className="relative w-full h-full">
                                        <img
                                             src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrString)}`}
                                             alt={titleText}
                                             className="w-full h-full object-contain"
                                        />
                                   </div>
                              ) : (
                                   <div className="text-slate-400 text-2xs uppercase tracking-wider font-bold">No QR Code</div>
                              )}
                         </div>
                    </div>

                    {/* Scan instructions text */}
                    <p className="text-[11px] font-semibold text-slate-400 text-center leading-relaxed max-w-[240px] mt-5 mb-1 select-none">
                         {scanInstructionText}
                    </p>

                    {/* Control Actions */}
                    <div className="w-full flex flex-col gap-2.5 mt-6">
                         {abapayDeeplink && (
                              <a
                                   href={abapayDeeplink}
                                   target="_blank"
                                   rel="noopener noreferrer"
                                   className={`w-full py-3 ${buttonBg} text-white rounded-[5px] text-xs font-bold uppercase tracking-wider text-center no-underline shadow-sm transition-all duration-200 flex items-center justify-center gap-2 border-none cursor-pointer active:scale-[0.98]`}
                              >
                                   <FiSmartphone className="w-4 h-4" />
                                   {payButtonText}
                              </a>
                         )}
                         <button
                              onClick={handleVerify}
                              disabled={isVerifying || isLoadingQr}
                              className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-[5px] text-xs font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer shadow-sm focus:outline-none flex items-center justify-center gap-2 border-none disabled:opacity-50 active:scale-[0.98]"
                         >
                              {isVerifying ? (
                                   <>
                                        <FiLoader className="w-4 h-4 animate-spin" />
                                        Verifying...
                                   </>
                              ) : (
                                   <>
                                        <FiCheck className="w-4 h-4 stroke-[3]" />
                                        Confirm Sandbox Payment
                                   </>
                              )}
                         </button>
                    </div>
               </div>
          </div>,
          document.body
     );
};
