import React, { useState, useEffect } from 'react';
import { FiShoppingBag, FiHeart, FiBell, FiSearch, FiLogOut, FiClock, FiX, FiUser, FiGift, FiMapPin, FiMessageSquare, FiChevronDown } from 'react-icons/fi';
import '../styles/animation.css';
import type { NavbarPageProps, MegaMenuColumn, MegaMenuConfig } from '../types';
import { FASHION_ROUTES } from '../routes';
import { resolveImageUrl } from '../utils/imageUtils';
import { useSearch } from '../hooks/useSearch';
import { Store_setting, type StoreRow } from '@/api/owner/stores';
import { LoginPage } from './auth/LoginPage';
import { RegisterPage } from './auth/RegisterPage';
import { LogoutConfirm } from '../message/Comfirmd';
import { LogoutLoadingOverlay } from '../message/LoadingTime';


export const NavbarPage: React.FC<NavbarPageProps> = ({
  cartCount,
  favoritesCount,
  setIsCartOpen,
  searchQuery = '',
  onSearch,
  user,
  storeName: initialStoreName = '',
  stores: initialStores,
  onNavigate,
  categories,
  onLogin,
  onRegister,
  onLogout,
  isSubmitting,
  isAuthLoading = false,
  ownerUserId,
}) => {
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);
  const [notificationsCount] = useState(0);
  const [authModal, setAuthModal] = useState<'login' | 'register' | null>(null);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [showLogoutLoading, setShowLogoutLoading] = useState(false);
  const [isProfileDropdownOpen, setIsProfileDropdownOpen] = useState(false);

  // Scroll responsive sticky header states
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('fashion_recent_searches');
    if (stored) {
      try {
        setRecentSearches(JSON.parse(stored));
      } catch (e) {
        console.warn('Failed to parse recent searches', e);
      }
    }
  }, []);

  const addToRecentSearches = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;
    setRecentSearches(prev => {
      const filtered = prev.filter(item => item.toLowerCase() !== trimmed.toLowerCase());
      const updated = [trimmed, ...filtered].slice(0, 10);
      localStorage.setItem('fashion_recent_searches', JSON.stringify(updated));
      return updated;
    });
  };

  const removeFromRecentSearches = (query: string) => {
    setRecentSearches(prev => {
      const updated = prev.filter(item => item !== query);
      localStorage.setItem('fashion_recent_searches', JSON.stringify(updated));
      return updated;
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem('fashion_recent_searches');
  };

  const {
    matchedProducts,
    matchedCategories,
    allMatchedProducts,
    allMatchedCategories,
    isLoading: isSearchLoading
  } = useSearch({
    ownerUserId,
    searchQuery,
    categories,
    limit: 5,
  });

  // Local state to track dynamic settings for real-time updates
  const [dynamicStores, setDynamicStores] = useState<StoreRow | null>(initialStores || Store_setting());
  const [dynamicMenuConfigs, setDynamicMenuConfigs] = useState<MegaMenuConfig | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      // Close hover mega-menu dropdown when scrolling
      setHoveredCategory(null);

      if (currentScrollY > 100) {
        if (currentScrollY > lastScrollY) {
          // Scrolling down - hide navbar
          setIsVisible(false);
        } else {
          // Scrolling up - reveal navbar
          setIsVisible(true);
        }
      } else {
        // Near the top - always show
        setIsVisible(true);
      }
      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [lastScrollY]);

  useEffect(() => {
    const handleUpdate = () => {
      const updated = Store_setting();
      if (updated) setDynamicStores(updated);
    };
    const handleRequestLogin = () => {
      setAuthModal('login');
    };
    window.addEventListener('settings_updated', handleUpdate);
    window.addEventListener('request_login', handleRequestLogin);
    return () => {
      window.removeEventListener('settings_updated', handleUpdate);
      window.removeEventListener('request_login', handleRequestLogin);
    };
  }, []);

  // Click outside listener to close categories dropdown and profile dropdown
  useEffect(() => {
    const handleClickOutside = () => {
      setHoveredCategory(null);
      setIsProfileDropdownOpen(false);
    };
    window.addEventListener('click', handleClickOutside);
    return () => {
      window.removeEventListener('click', handleClickOutside);
    };
  }, []);


  // Update dynamic stores if props change
  useEffect(() => {
    if (initialStores) setDynamicStores(initialStores);
  }, [initialStores]);

  // Transform categories into MegaMenuConfig format
  useEffect(() => {
    if (categories && categories.length > 0) {
      const config: MegaMenuConfig = {};

      // Get root categories (level 1) that should be in menu
      const roots = categories.filter(c => !c.parent_id && c.is_menu);

      roots.forEach(root => {
        const columns: MegaMenuColumn[] = [];

        // Level 2: Subcategories (Columns)
        const subCats = categories.filter(c => c.parent_id === root.id && c.is_menu);

        if (subCats.length > 0) {
          subCats.forEach(child => {
            const items: string[] = [];

            // Level 3: Items
            const grandchildren = categories.filter(c => c.parent_id === child.id && c.is_menu);
            if (grandchildren.length > 0) {
              grandchildren.forEach(subChild => {
                items.push(subChild.name);
              });
            } else {
              // Fallback if no sub-children: just add "All" or same as parent
              items.push(`All ${child.name}`);
            }

            columns.push({
              title: child.name,
              items: items
            });
          });
        }

        if (columns.length > 0) {
          config[root.name.toUpperCase()] = columns;
        }
      });

      if (Object.keys(config).length > 0) {
        setDynamicMenuConfigs(config);
      }
    } else {
      setDynamicMenuConfigs(null);
    }
  }, [categories]);

  const activeStores = dynamicStores || initialStores;
  const rawStoreName = activeStores?.store_name || initialStoreName;
  // Guard: if JS serialized a null value to the string "null", fall through to the default
  const activeStoreName = (rawStoreName && rawStoreName !== 'null') ? rawStoreName : 'Prime Store';


  const activeMenuConfigs = dynamicMenuConfigs || {};

  const logoUrl = activeStores?.logo_url
    ? resolveImageUrl(activeStores.logo_url)
    : (activeStores?.favicon_url ? resolveImageUrl(activeStores.favicon_url) : '');

  return (
    <>
      <div
        className={`sticky top-0 z-50 bg-white border-b border-stone-200/60 shadow-2xs font-sans transition-transform duration-300 ease-in-out ${isVisible ? 'translate-y-0' : '-translate-y-full'
          }`}
      >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4 relative">

        {/* Center: Brand Logo */}
        <div className="flex-1 lg:flex-none flex justify-center">
          {logoUrl ? (
            <img
              src={logoUrl}
              alt={activeStoreName}
              onClick={() => {
                if (onNavigate) {
                  const storeSlug = activeStoreName.replace(/\s+/g, '_');
                  onNavigate(FASHION_ROUTES.getHome(storeSlug, ownerUserId));
                }
              }}
              className="h-10 w-auto object-contain cursor-pointer transition-transform duration-300 hover:scale-105"
            />
          ) : (
            <span
              onClick={() => {
                if (onNavigate) {
                  const storeSlug = activeStoreName.replace(/\s+/g, '_');
                  onNavigate(FASHION_ROUTES.getHome(storeSlug, ownerUserId));
                }
              }}
              className="font-sans font-black text-2xl tracking-[0.2em] uppercase text-stone-950 select-none cursor-pointer"
            >
              {activeStoreName}
            </span>
          )}
        </div>
        {/* Center/Left: Category Nav Links */}
        <div className="hidden lg:flex items-center space-x-6 text-2xs font-extrabold tracking-widest text-stone-855 uppercase h-full">
          {/* Static Link Shop */}
          <div
            onClick={() => {
              if (onNavigate) {
                const storeSlug = activeStoreName.replace(/\s+/g, '_');
                onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug));
              }
            }}
            className="h-full flex items-center relative cursor-pointer"
          >
            <span className="nav-link-draw hover:text-[#E61E25] text-stone-800 transition-colors py-8">
              SHOP
            </span>
          </div>

          {Object.keys(activeMenuConfigs).map(catKey => {
            return (
              <div
                key={catKey}
                onClick={(e) => {
                  e.stopPropagation();
                  setHoveredCategory(prev => prev === catKey ? null : catKey);
                }}
                className="h-full flex items-center cursor-pointer"
              >
                <span
                  className={`nav-link-draw hover:text-[#E61E25] transition-colors py-8 ${hoveredCategory === catKey ? 'text-[#E61E25]' : 'text-stone-800'
                    }`}
                >
                  {catKey}
                </span>

                {/* Dropdown Container Positioned Relative to the Category Link */}
                {hoveredCategory === catKey && activeMenuConfigs[catKey] && (
                  <div
                    className="absolute top-full left-0 w-full bg-white border border-stone-200/80 shadow-xl z-55 animate-fade-in-down p-8 rounded-[4px] flex gap-12 text-left mt-0"
                    onClick={(e) => e.stopPropagation()} // Prevent click bubbling to toggle parent dropdown
                  >
                    {activeMenuConfigs[catKey].map((col: MegaMenuColumn, idx: number) => (
                      <div key={idx} className="space-y-4 min-w-[120px]">
                        {/* Column Title (Sub Category) */}
                        <h5
                          onClick={() => {
                            if (onNavigate) {
                              const storeSlug = activeStoreName.replace(/\s+/g, '_');
                              const subCatHash = `${catKey.toLowerCase()}-${col.title
                                .toLowerCase()
                                .replace(/[^a-z0-9]/g, '-')}`;
                              onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug, { hash: `#${subCatHash}` }));
                            }
                            setHoveredCategory(null);
                          }}
                          className={`text-2xs font-black tracking-widest uppercase mega-menu-column-title cursor-pointer hover:text-[#E61E25] transition-colors ${col.isRed
                            ? 'text-[#E61E25] after:bg-[#E61E25]'
                            : 'text-stone-950 after:bg-stone-950'
                            }`}
                        >
                          {col.title}
                        </h5>

                        {/* Column Items (Sub Sub Categories) */}
                        <ul className="space-y-2 list-none p-2 m-0">
                          {col.items.map((item: string, itemIdx: number) => {
                            const targetHash = `${catKey.toLowerCase()}-${item
                              .toLowerCase()
                              .replace(/[^a-z0-9]/g, '-')}`;
                            return (
                              <li key={itemIdx}>
                                <a
                                  href={`#${targetHash}`}
                                  onClick={e => {
                                    if (onNavigate) {
                                      e.preventDefault();
                                      const storeSlug = activeStoreName.replace(/\s+/g, '_');
                                      onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug, { hash: `#${targetHash}` }));
                                    }
                                    setHoveredCategory(null);
                                  }}
                                  className={`mega-menu-item text-[12px] font-bold transition-colors no-underline block ${col.isRed
                                    ? 'text-[#E61E25]'
                                    : 'text-stone-500 hover:text-[#E61E25]'
                                    }`}
                                >
                                  {item}
                                </a>
                              </li>
                            );
                          })}
                        </ul>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>


        {/* Right: Search, Tools, Auth */}
        <div className="flex items-center space-x-4">
          {/* Search Input */}
          <div className="hidden md:block">
            <div className="relative">
              <FiSearch className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400 w-3.5 h-3.5" />
              <input
                type="text"
                placeholder="Search..."
                value={searchQuery}
                onChange={e => onSearch && onSearch(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter') {
                    addToRecentSearches(searchQuery);
                    if (onNavigate) {
                      const storeSlug = activeStoreName.replace(/\s+/g, '_');
                      onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug, { search: searchQuery }));
                    }
                    setIsSearchFocused(false);
                    (e.target as HTMLInputElement).blur();
                  }
                }}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
                className="pl-9 pr-4 py-2 w-44 hover:w-56 focus:w-56 bg-stone-100/80 border border-transparent rounded-[6px] text-2xs font-bold text-stone-800 placeholder-stone-400 outline-none transition-all duration-355 focus:bg-white focus:border-stone-300"
              />
            </div>

            {isSearchFocused && searchQuery.trim().length === 0 && (
              <div
                onMouseDown={(e) => e.preventDefault()}
                className="absolute top-full left-0 w-full mt-2 max-h-96 overflow-y-auto bg-white border border-stone-200/80 rounded-[8px] shadow-xl z-55 p-6 font-sans text-left animate-fade-in-down"
              >
                <div className="flex items-center justify-between border-b border-stone-100 pb-1.5 mb-3">
                  <h4 className="text-[10px] font-black text-stone-400 uppercase tracking-widest">
                    Recent Searches
                  </h4>
                  {recentSearches.length > 0 && (
                    <button
                      type="button"
                      onClick={() => clearRecentSearches()}
                      className="text-stone-400 hover:text-stone-900 text-3xs font-black uppercase tracking-wider bg-transparent border-none cursor-pointer p-0"
                    >
                      Clear All
                    </button>
                  )}
                </div>
                {recentSearches.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    {recentSearches.map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between hover:bg-stone-55 rounded-[4px] px-3 py-2 transition-colors group cursor-pointer border border-stone-200/60"
                        onClick={() => {
                          if (onSearch) onSearch(item);
                          if (onNavigate) {
                            const storeSlug = activeStoreName.replace(/\s+/g, '_');
                            onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug, { search: item }));
                          }
                          setIsSearchFocused(false);
                        }}
                      >
                        <div className="flex items-center gap-2 text-stone-700 group-hover:text-stone-900 flex-1 min-w-0">
                          <FiClock className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                          <span className="text-2xs font-extrabold uppercase tracking-wide truncate">
                            {item}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeFromRecentSearches(item);
                          }}
                          className="p-1 hover:bg-stone-200/60 rounded-full text-stone-400 hover:text-stone-700 bg-transparent border-none cursor-pointer flex items-center justify-center transition-colors"
                        >
                          <FiX className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-4 text-stone-400 text-3xs font-bold uppercase tracking-wider">
                    No recent searches
                  </div>
                )}
              </div>
            )}

            {isSearchFocused && searchQuery.trim().length > 0 && (
              <div
                onMouseDown={(e) => e.preventDefault()}
                className="absolute top-full left-0 w-full mt-2 max-h-96 overflow-y-auto bg-white border border-stone-200/80 rounded-[8px] shadow-xl z-55 p-6 font-sans text-left animate-fade-in-down"
              >
                {isSearchLoading ? (
                  <div className="flex items-center justify-center py-6 text-stone-400 text-3xs font-bold uppercase tracking-wider">
                    <div className="animate-spin h-4 w-4 border-2 border-stone-900 border-t-transparent rounded-full mr-2" />
                    Searching...
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                      {/* Categories section */}
                      {matchedCategories.length > 0 && (
                        <div className="md:col-span-4 space-y-1.5">
                          <h4 className="text-[10px] font-black text-stone-400 uppercase tracking-widest border-b border-stone-100 pb-1">
                            Categories
                          </h4>
                          <div className="flex flex-col">
                            {matchedCategories.map(cat => {
                              const nameNormalized = cat.name.toLowerCase().replace(/[^a-z0-9]/g, '-');
                              return (
                                <button
                                  key={cat.id}
                                  onClick={() => {
                                    addToRecentSearches(searchQuery);
                                    if (onNavigate) {
                                      const storeSlug = activeStoreName.replace(/\s+/g, '_');
                                      onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug, { hash: `#${nameNormalized}` }));
                                    }
                                  }}
                                  className="text-left px-2 py-1.5 hover:bg-stone-50 text-stone-700 hover:text-[#E61E25] font-extrabold text-3xs uppercase tracking-wider rounded-[4px] transition-colors border-none bg-transparent cursor-pointer w-full"
                                >
                                  {cat.name}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Products section */}
                      {matchedProducts.length > 0 && (
                        <div className={`${matchedCategories.length > 0 ? 'md:col-span-8' : 'md:col-span-12'} space-y-1.5`}>
                          <h4 className="text-[10px] font-black text-stone-400 uppercase tracking-widest border-b border-stone-100 pb-1">
                            Products
                          </h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            {matchedProducts.map(product => (
                              <div
                                key={product.id}
                                onClick={() => {
                                  addToRecentSearches(searchQuery);
                                  if (onNavigate) {
                                    const storeSlug = activeStoreName.replace(/\s+/g, '_');
                                    onNavigate(FASHION_ROUTES.getProduct(product.id, ownerUserId, storeSlug));
                                  }
                                }}
                                className="flex gap-3 items-center p-1.5 hover:bg-stone-50 rounded-[4px] cursor-pointer transition-colors"
                              >
                                <div className="w-8 h-10 rounded-[2px] overflow-hidden border border-stone-200 bg-white shrink-0">
                                  <img
                                    src={resolveImageUrl(product.display_image || product.image)}
                                    alt={product.name}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <div className="space-y-0.5 flex-1 min-w-0">
                                  <h5 className="text-[11px] font-black text-stone-800 uppercase tracking-wide truncate">
                                    {product.name}
                                  </h5>
                                  <div className="text-3xs font-extrabold font-mono text-stone-500">
                                    ${parseFloat(product.price).toFixed(2)}
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    {matchedCategories.length === 0 && matchedProducts.length === 0 && (
                      <div className="text-center py-6 text-stone-400 text-3xs font-bold uppercase tracking-wider">
                        No matches found
                      </div>
                    )}

                     {(allMatchedProducts.length > 0 || allMatchedCategories.length > 0) && (
                      <button
                        onClick={() => {
                          addToRecentSearches(searchQuery);
                          if (onNavigate) {
                            const storeSlug = activeStoreName.replace(/\s+/g, '_');
                            onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug, { search: searchQuery }));
                          }
                          setIsSearchFocused(false);
                        }}
                        className="w-full mt-3 py-2 bg-stone-955 hover:bg-stone-900 text-white font-extrabold text-[10px] uppercase tracking-widest transition-all rounded-[4px] border-none cursor-pointer flex items-center justify-center gap-1 shadow-2xs hover:shadow-xs"
                      >
                        View All Results ({allMatchedProducts.length + allMatchedCategories.length})
                      </button>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Notification Bell */}
          <button className="icon-scale-hover relative p-2 text-stone-800 hover:text-stone-600 bg-transparent border-none cursor-pointer transition-colors flex items-center justify-center focus:outline-none">
            <FiBell className="w-5 h-5" />
            {notificationsCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#E61E25] rounded-full" />
            )}
          </button>

          {/* Favorites Heart */}
          <button
            onClick={() => {
              if (onNavigate) {
                const storeSlug = (activeStores?.store_name || initialStoreName || 'store').replace(/\s+/g, '_');
                onNavigate(FASHION_ROUTES.getWishlist(ownerUserId, storeSlug));
              }
            }}
            className="icon-scale-hover p-2 text-stone-800 hover:text-[#E61E25] bg-transparent border-none cursor-pointer transition-colors flex items-center justify-center focus:outline-none relative"
          >
            <FiHeart className={`w-5 h-5 ${favoritesCount > 0 ? 'text-[#E61E25]' : ''}`} />
            {favoritesCount > 0 && (
              <span className="absolute top-0 right-0 w-5 h-3 text-[#E61E25] text-[13px] font-black rounded-full flex items-center justify-center">
                {favoritesCount}
              </span>
            )}
          </button>

          {/* Shopping Bag Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="icon-scale-hover relative p-2 text-stone-800 hover:text-stone-600 bg-transparent border-none cursor-pointer transition-colors flex items-center justify-center focus:outline-none"
          >
            <FiShoppingBag className={`w-5 h-5 ${cartCount > 0 ? '' : ''}`} />
            {cartCount > 0 && (
              <span
                key={cartCount}
                className="absolute top-0 right-0 w-4 h-4 bg-[#E61E25] text-white text-[9px] font-bold rounded-full flex items-center justify-center border border-white shadow-xs animate-cart-pop"
              >
                {cartCount}
              </span>
            )}
          </button>

          {/* Divider */}
          <span className="h-4 w-px bg-stone-200 hidden sm:block" />

          {/* Auth Links / Profile */}
          <div className="hidden sm:flex items-center space-x-3 text-3xs font-black tracking-widest text-stone-600 uppercase">
            {isAuthLoading ? (
              // Session resolving — render an invisible spacer to keep layout stable
              <div style={{ width: '80px', height: '16px' }} />
            ) : user ? (
              <div className="flex items-center gap-4">
                {/* Admin/Owner Dashboard Link */}
                {(user.role === 'owner' || user.role === 'admin' || user.role === 'staff') && (
                  <button
                    onClick={() => {
                      if (onNavigate) onNavigate(FASHION_ROUTES.getOwnerDashboard());
                    }}
                    className="hover:text-stone-900 bg-transparent border-none cursor-pointer transition-colors font-bold focus:outline-none flex items-center gap-1.5"
                    title="Go to Management Dashboard"
                  >
                    <span className="w-1.5 h-1.5 bg-red-500 rounded-full animate-pulse" />
                    Dashboard
                  </button>
                )}

                <div className="relative">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsProfileDropdownOpen(prev => !prev);
                    }}
                    className="flex items-center gap-2 hover:text-stone-900 bg-transparent border-none cursor-pointer transition-colors font-bold focus:outline-none"
                  >
                    {user.image_url ? (
                      <img src={user.image_url} alt={user.name} className="w-5 h-5 rounded-full object-cover border border-stone-200" />
                    ) : (
                      <div className="w-5 h-5 rounded-full bg-stone-900 text-white flex items-center justify-center text-[8px] font-black">
                        {user.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <span className="max-w-[80px] truncate">{user.name.split(' ')[0]}</span>
                    <FiChevronDown className={`w-3 h-3 transition-transform duration-200 ${isProfileDropdownOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {isProfileDropdownOpen && (
                    <div className="absolute right-0 top-12 mt-2 w-52 bg-white border border-stone-200/80 rounded-[4px] shadow-xl z-55 p-2.5 text-left animate-fade-in-down normal-case font-semibold text-stone-750 flex flex-col">
                      <button
                        onClick={() => {
                          const storeSlug = (initialStores?.store_name || initialStoreName || 'store').replace(/\s+/g, '_');
                          setIsProfileDropdownOpen(false);
                          if (onNavigate) onNavigate(FASHION_ROUTES.getProfile(ownerUserId, storeSlug, 'profile'));
                        }}
                        className="flex items-center gap-2 px-3 py-2 text-[10px] font-bold text-stone-600 hover:text-stone-900 hover:bg-stone-50 rounded-[3px] bg-transparent border-none cursor-pointer w-full text-left transition-colors focus:outline-none uppercase tracking-wider"
                      >
                        <FiUser className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        Profile
                      </button>
                      <button
                        onClick={() => {
                          const storeSlug = (initialStores?.store_name || initialStoreName || 'store').replace(/\s+/g, '_');
                          setIsProfileDropdownOpen(false);
                          if (onNavigate) onNavigate(FASHION_ROUTES.getProfile(ownerUserId, storeSlug, 'orders'));
                        }}
                        className="flex items-center gap-2 px-3 py-2 text-[10px] font-bold text-stone-600 hover:text-stone-900 hover:bg-stone-50 rounded-[3px] bg-transparent border-none cursor-pointer w-full text-left transition-colors focus:outline-none uppercase tracking-wider"
                      >
                        <FiClock className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        Order History
                      </button>
                      <button
                        onClick={() => {
                          const storeSlug = (initialStores?.store_name || initialStoreName || 'store').replace(/\s+/g, '_');
                          setIsProfileDropdownOpen(false);
                          if (onNavigate) onNavigate(FASHION_ROUTES.getProfile(ownerUserId, storeSlug, 'giftcard'));
                        }}
                        className="flex items-center gap-2 px-3 py-2 text-[10px] font-bold text-stone-600 hover:text-stone-900 hover:bg-stone-50 rounded-[3px] bg-transparent border-none cursor-pointer w-full text-left transition-colors focus:outline-none uppercase tracking-wider"
                      >
                        <FiGift className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        Vouchers & Gift Cards
                      </button>
                      <button
                        onClick={() => {
                          const storeSlug = (initialStores?.store_name || initialStoreName || 'store').replace(/\s+/g, '_');
                          setIsProfileDropdownOpen(false);
                          if (onNavigate) onNavigate(FASHION_ROUTES.getProfile(ownerUserId, storeSlug, 'address'));
                        }}
                        className="flex items-center gap-2 px-3 py-2 text-[10px] font-bold text-stone-600 hover:text-stone-900 hover:bg-stone-50 rounded-[3px] bg-transparent border-none cursor-pointer w-full text-left transition-colors focus:outline-none uppercase tracking-wider"
                      >
                        <FiMapPin className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        Address Book
                      </button>
                      <button
                        onClick={() => {
                          const storeSlug = (initialStores?.store_name || initialStoreName || 'store').replace(/\s+/g, '_');
                          setIsProfileDropdownOpen(false);
                          if (onNavigate) onNavigate(FASHION_ROUTES.getProfile(ownerUserId, storeSlug, 'chat'));
                        }}
                        className="flex items-center gap-2 px-3 py-2 text-[10px] font-bold text-stone-600 hover:text-stone-900 hover:bg-stone-50 rounded-[3px] bg-transparent border-none cursor-pointer w-full text-left transition-colors focus:outline-none uppercase tracking-wider"
                      >
                        <FiMessageSquare className="w-3.5 h-3.5 text-stone-400 shrink-0" />
                        Massager Chat
                      </button>
                      {onLogout && (
                        <button
                          onClick={() => {
                            setIsProfileDropdownOpen(false);
                            setShowLogoutConfirm(true);
                          }}
                          className="flex items-center gap-2 px-3 py-2 text-[10px] font-bold text-stone-600 hover:text-red-500 hover:bg-stone-50 rounded-[3px] bg-transparent border-none cursor-pointer w-full text-left transition-colors focus:outline-none uppercase tracking-wider"
                        >
                          <FiLogOut className="w-3.5 h-3.5 text-stone-400 shrink-0 hover:text-red-400" />
                          Sign out
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              // Show login/register links if not logged in
              <>
                <button
                  onClick={() => setAuthModal('login')}
                  className="hover:text-stone-900 bg-transparent border-none cursor-pointer transition-colors font-bold focus:outline-none"
                >
                  Login
                </button>
                <span className="text-stone-300 font-normal">|</span>
                <button
                  onClick={() => setAuthModal('register')}
                  className="hover:text-stone-900 bg-transparent border-none cursor-pointer transition-colors font-bold focus:outline-none"
                >
                  Register
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Modals are rendered outside of the sticky container context */}


      </div>

      {/* Auth Modals */}
      {authModal === 'login' && onLogin && (
        <LoginPage
          onClose={() => setAuthModal(null)}
          onLogin={onLogin}
          onSwitchToRegister={() => setAuthModal('register')}
          isSubmitting={isSubmitting}
          storeName={activeStoreName}
          stores={dynamicStores || undefined}
          ownerUserId={ownerUserId}
        />
      )}
      {authModal === 'register' && onRegister && (
        <RegisterPage
          onClose={() => setAuthModal(null)}
          onRegister={onRegister}
          onSwitchToLogin={() => setAuthModal('login')}
          isSubmitting={isSubmitting}
          storeName={activeStoreName}
        />
      )}

      {/* Logout Confirmation Dialog */}
      {showLogoutConfirm && (
        <LogoutConfirm
          storeName={activeStoreName}
          userName={user?.name}
          onCancel={() => setShowLogoutConfirm(false)}
          onConfirm={() => {
            setShowLogoutConfirm(false);
            setShowLogoutLoading(true);
          }}
        />
      )}

      {/* Logout Loading Overlay */}
      {showLogoutLoading && (
        <LogoutLoadingOverlay
          storeName={activeStoreName}
          onDone={() => {
            setShowLogoutLoading(false);
            onLogout?.();
            // Navigate to store home — NOT reload (would return to profile/current page)
            const storeSlug = activeStoreName.replace(/\s+/g, '_');
            if (onNavigate && storeSlug) {
              onNavigate(FASHION_ROUTES.getHome(storeSlug));
            } else {
              window.location.href = '/';
            }
          }}
        />
      )}
    </>
  );
};
