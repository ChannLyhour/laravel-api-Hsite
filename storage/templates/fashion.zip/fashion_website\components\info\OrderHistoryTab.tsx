import React, { useState, useEffect } from 'react';
import { 
    FiShoppingBag, 
    FiChevronDown, 
    FiChevronUp, 
    FiPackage, 
    FiMapPin, 
    FiCreditCard, 
    FiClock,
    FiCheckCircle,
    FiXCircle,
    FiCheck,
    FiTag,
} from 'react-icons/fi';
import { toast } from 'react-hot-toast';
import { customerOrdersService } from '@/api/created_by/getOrderCustomerbyid';
import { resolveImageUrl } from '@/api/imageUtils';
import type { Order } from '@/pages/owner_manage/components/order/show';

interface OrderHistoryTabProps {
    user: any;
    ownerUserId?: number | string;
}

// Fallback images for fashion/boutique
const getItemFallbackImage = (name?: string): string => {
    if (!name) return 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=150&q=80';
    
    const lowercase = name.toLowerCase();
    if (lowercase.includes('shirt') || lowercase.includes('tee')) {
        return 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=150&q=80';
    }
    if (lowercase.includes('dress')) {
        return 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=150&q=80';
    }
    if (lowercase.includes('pants') || lowercase.includes('jeans')) {
        return 'https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&w=150&q=80';
    }
    if (lowercase.includes('bag')) {
        return 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&w=150&q=80';
    }
    if (lowercase.includes('shoe') || lowercase.includes('sneaker')) {
        return 'https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&w=150&q=80';
    }
    return 'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=150&q=80';
};

const resolveItemImage = (item: any): string => {
    if (item.image && typeof item.image === 'string' && item.image.trim() !== '') {
        return resolveImageUrl(item.image);
    }
    return getItemFallbackImage(item.name);
};

const formatOrderDate = (timeStr: string): string => {
    try {
        const d = new Date(timeStr);
        if (isNaN(d.getTime())) return timeStr;
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric', month: 'short', day: 'numeric',
            hour: 'numeric', minute: '2-digit'
        }).format(d);
    } catch {
        return timeStr;
    }
};

const getActiveStepIndex = (status: string): number => {
    const s = status.toLowerCase();
    if (s.includes('complete') || s.includes('deliver')) return 3;
    if (s.includes('process')) return 2;
    if (s.includes('confirm')) return 1;
    return 0; // Default/pending
};

const playGentleNotificationChime = () => {
    try {
        const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioContext) return;
        const ctx = new AudioContext();
        const now = ctx.currentTime;

        // Tone 1: E5 (659.25 Hz)
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(659.25, now);
        gain1.gain.setValueAtTime(0, now);
        gain1.gain.linearRampToValueAtTime(0.1, now + 0.05);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc1.connect(gain1);
        gain1.connect(ctx.destination);

        // Tone 2: A5 (880.00 Hz)
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(880.00, now + 0.1);
        gain2.gain.setValueAtTime(0, now + 0.1);
        gain2.gain.linearRampToValueAtTime(0.1, now + 0.15);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);

        osc1.start(now);
        osc1.stop(now + 0.3);
        osc2.start(now + 0.1);
        osc2.stop(now + 0.4);
    } catch (error) {
        console.warn('Audio chime failed to play', error);
    }
};

export const OrderHistoryTab: React.FC<OrderHistoryTabProps> = ({ user, ownerUserId }) => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [isLoadingOrders, setIsLoadingOrders] = useState(false);
    const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);

    useEffect(() => {
        if (orders.length > 0) {
            const params = new URLSearchParams(window.location.search);
            const orderIdParam = params.get('order_id');
            if (orderIdParam) {
                const exists = orders.some(o => String(o.id) === String(orderIdParam));
                if (exists) {
                    setExpandedOrderId(String(orderIdParam));
                }
            }
        }
    }, [orders]);

    const fetchOrders = () => {
        setIsLoadingOrders(true);
        customerOrdersService.getOrdersByCustomerId(user?.id, ownerUserId)
            .then((data: any[]) => {
                setOrders(data || []);
            })
            .catch((err: any) => {
                console.error('Failed to load orders', err);
                toast.error('Could not load order history');
                setOrders([]);
            })
            .finally(() => setIsLoadingOrders(false));
    };

    useEffect(() => {
        if (!user) {
            setOrders([]);
            return;
        }

        // Fetch initial orders with loading state
        fetchOrders();

        // Establish background polling interval
        const intervalId = setInterval(() => {
            customerOrdersService.getOrdersByCustomerId(user.id, ownerUserId)
                .then((data: any[]) => {
                    if (!data) return;

                    setOrders(prevOrders => {
                        if (prevOrders.length === 0) {
                            return data;
                        }

                        let stateChanged = false;
                        const newOrdersList = [...prevOrders];

                        data.forEach(latestOrder => {
                            const matchIdx = newOrdersList.findIndex(o => o.id === latestOrder.id);
                            if (matchIdx !== -1) {
                                const oldOrder = newOrdersList[matchIdx];
                                const statusChanged = oldOrder.status !== latestOrder.status;
                                const paymentChanged = oldOrder.paymentStatus !== latestOrder.paymentStatus;

                                if (statusChanged || paymentChanged) {
                                    newOrdersList[matchIdx] = latestOrder;
                                    stateChanged = true;

                                    if (statusChanged) {
                                        playGentleNotificationChime();
                                        toast.custom((t) => (
                                            <div className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-sm w-full bg-white shadow-lg rounded-lg pointer-events-auto border border-stone-200 p-4 flex items-start gap-3`}>
                                                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center text-stone-800">
                                                    <FiPackage className="w-4 h-4" />
                                                </div>
                                                <div className="flex-1">
                                                    <p className="text-xs font-bold text-stone-900">Order #{latestOrder.order_no || latestOrder.id} Update</p>
                                                    <p className="text-[11px] text-stone-500 mt-0.5">
                                                        Status updated to <span className="font-semibold text-stone-800 capitalize">{latestOrder.status}</span>.
                                                    </p>
                                                </div>
                                            </div>
                                        ), { duration: 5000 });
                                    }

                                    if (paymentChanged) {
                                        if (!statusChanged) {
                                            playGentleNotificationChime();
                                        }
                                        toast.custom((t) => (
                                            <div className={`${t.visible ? 'animate-enter' : 'animate-leave'} max-w-sm w-full bg-white shadow-lg rounded-lg pointer-events-auto border border-stone-200 p-4 flex items-start gap-3`}>
                                                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-600">
                                                    <FiCreditCard className="w-4 h-4" />
                                                </div>
                                                <div className="flex-1">
                                                    <p className="text-xs font-bold text-stone-900">Payment Update</p>
                                                    <p className="text-[11px] text-stone-500 mt-0.5">
                                                        Order #{latestOrder.order_no || latestOrder.id} payment is now <span className="font-semibold text-emerald-600 capitalize">{latestOrder.paymentStatus}</span>.
                                                    </p>
                                                </div>
                                            </div>
                                        ), { duration: 5000 });
                                    }
                                }
                            } else {
                                // New order placed
                                newOrdersList.unshift(latestOrder);
                                stateChanged = true;
                            }
                        });

                        return stateChanged ? newOrdersList : prevOrders;
                    });
                })
                .catch(err => {
                    console.warn('Silent orders poll error:', err);
                });
        }, 10000); // 10 seconds

        return () => {
            clearInterval(intervalId);
        };
    }, [user, ownerUserId]);

    const getStatusConfig = (status: string) => {
        const s = status.toLowerCase();
        if (s.includes('pending')) return { color: 'bg-amber-100 text-amber-800', icon: <FiClock className="w-3 h-3" />, label: 'Pending' };
        if (s.includes('process')) return { color: 'bg-blue-100 text-blue-800', icon: <FiPackage className="w-3 h-3" />, label: 'Processing' };
        if (s.includes('complete') || s.includes('deliver')) return { color: 'bg-emerald-100 text-emerald-800', icon: <FiCheckCircle className="w-3 h-3" />, label: 'Delivered' };
        if (s.includes('cancel')) return { color: 'bg-rose-100 text-rose-800', icon: <FiXCircle className="w-3 h-3" />, label: 'Cancelled' };
        return { color: 'bg-stone-100 text-stone-800', icon: <FiPackage className="w-3 h-3" />, label: status };
    };

    return (
        <div className="space-y-8 animate-fade-in">
            {/* Header */}
            <div className="flex items-center gap-3 border-b border-stone-200 pb-4">
                <div className="p-2 bg-stone-100 rounded-full text-stone-800">
                    <FiShoppingBag className="w-5 h-5" />
                </div>
                <div>
                    <h2 className="text-lg font-black text-stone-900 tracking-tight">Order History</h2>
                    <p className="text-xs text-stone-500 mt-0.5">Track, manage, and review your recent purchases.</p>
                </div>
            </div>

            {/* Content */}
            {isLoadingOrders ? (
                <div className="py-20 flex flex-col justify-center items-center gap-4">
                    <div className="w-8 h-8 border-2 border-stone-200 border-t-stone-900 rounded-full animate-spin" />
                    <p className="text-xs font-bold text-stone-400 uppercase tracking-widest">Loading Orders...</p>
                </div>
            ) : orders.length === 0 ? (
                <div className="py-24 flex flex-col items-center justify-center text-center bg-stone-50/50 rounded-xl border border-stone-200/50 border-dashed">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center shadow-sm mb-4">
                        <FiShoppingBag className="w-6 h-6 text-stone-300" />
                    </div>
                    <h3 className="text-sm font-bold text-stone-900 mb-1">No orders yet</h3>
                    <p className="text-xs text-stone-500 max-w-[250px]">When you place an order, it will appear here for you to track its status.</p>
                </div>
            ) : (
                <div className="space-y-4">
                    {orders.map(order => {
                        const isExpanded = expandedOrderId === order.id;
                        const statusConfig = getStatusConfig(order.status);
                        const totalItemsCount = order.items.reduce((acc, item) => acc + (parseInt(item.qty as any) || 1), 0);

                        return (
                            <div
                                key={order.id}
                                className={`group rounded-xl border transition-all duration-300 bg-white ${
                                    isExpanded 
                                    ? 'border-stone-300 shadow-md' 
                                    : 'border-stone-200 shadow-sm hover:border-stone-300 hover:shadow-md cursor-pointer'
                                }`}
                            >
                                {/* Collapsed / Main Header Area */}
                                <div 
                                    className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                                    onClick={() => !isExpanded && setExpandedOrderId(order.id)}
                                >
                                    {/* Left: Info */}
                                    <div className="flex items-center gap-5">
                                        {/* Thumbnail cluster (show up to 2 items) */}
                                        <div className="hidden sm:flex items-center -space-x-2">
                                            {order.items.slice(0, 2).map((item, idx) => {
                                                console.log('[OrderHistory] Item Image:', item.image);
                                                return (
                                                    <img 
                                                        key={idx}
                                                        src={resolveItemImage(item)} 
                                                        alt={item.name}
                                                        className="w-12 h-12 rounded-[5px] object-cover border-2 border-white bg-stone-100 shadow-sm"
                                                    />
                                                );
                                            })}
                                            {order.items.length > 2 && (
                                                <div className="w-12 h-12 rounded-[5px] border-2 border-white bg-stone-100 flex items-center justify-center text-[10px] font-black text-stone-600 shadow-sm z-10">
                                                    +{order.items.length - 2}
                                                </div>
                                            )}
                                        </div>

                                        <div className="space-y-1.5">
                                            <div className="flex items-center gap-2">
                                                <span className="text-sm font-black text-stone-900 font-mono tracking-tight">#{order.order_no || order.id}</span>
                                                <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${statusConfig.color}`}>
                                                    {statusConfig.icon}
                                                    {statusConfig.label}
                                                </span>
                                            </div>
                                            <div className="flex items-center gap-2 text-xs text-stone-500 font-medium">
                                                <span>{formatOrderDate(order.time)}</span>
                                                <span className="w-1 h-1 bg-stone-300 rounded-full" />
                                                <span>{totalItemsCount} {totalItemsCount === 1 ? 'item' : 'items'}</span>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Right: Price & Action */}
                                    <div className="flex items-center justify-between sm:justify-end gap-6 w-full sm:w-auto border-t sm:border-t-0 border-stone-100 pt-3 sm:pt-0">
                                        <div className="text-left sm:text-right">
                                            <p className="text-[10px] font-bold text-stone-400 uppercase tracking-widest mb-0.5">Total Amount</p>
                                            <p className="text-base font-black text-stone-900 font-mono">${parseFloat(order.total).toFixed(2)}</p>
                                        </div>
                                        
                                        <button 
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                setExpandedOrderId(isExpanded ? null : order.id);
                                            }}
                                            className="p-2 bg-stone-50 hover:bg-stone-100 rounded-full text-stone-600 transition-colors border-none cursor-pointer"
                                        >
                                            {isExpanded ? <FiChevronUp className="w-5 h-5" /> : <FiChevronDown className="w-5 h-5" />}
                                        </button>
                                    </div>
                                </div>

                                {/* Expanded Details Area */}
                                {isExpanded && (
                                    <div className="border-t border-stone-100 bg-stone-50/50 rounded-b-xl p-5 sm:p-6 space-y-6 animate-fade-in">
                                        
                                        {/* Status Timeline */}
                                        {(() => {
                                            const activeStep = getActiveStepIndex(order.status);
                                            const isCanceled = order.status.toLowerCase().includes('cancel');
                                            
                                            const steps = [
                                                { title: 'Order Placed', desc: 'Received & pending', icon: <FiClock className="w-4 h-4" /> },
                                                { title: 'Confirmed', desc: 'Order confirmed', icon: <FiCheck className="w-4 h-4" /> },
                                                { title: 'Processing', desc: 'Preparing your items', icon: <FiPackage className="w-4 h-4" /> },
                                                { title: 'Delivered', desc: 'Package received', icon: <FiCheckCircle className="w-4 h-4" /> }
                                            ];

                                            if (isCanceled) {
                                                return (
                                                    <div className="bg-white p-4 sm:p-5 rounded-xl border border-stone-200/80 shadow-xs">
                                                        <div className="flex items-center gap-4">
                                                            <div className="w-10 h-10 rounded-full bg-rose-50 border-2 border-rose-500 text-rose-600 flex items-center justify-center shrink-0">
                                                                <FiXCircle className="w-5 h-5" />
                                                            </div>
                                                            <div>
                                                                <h4 className="text-xs font-black text-rose-950 uppercase tracking-widest">Order Cancelled</h4>
                                                                <p className="text-[10px] text-stone-500 font-medium mt-0.5">This transaction has been cancelled. If you have any questions, please contact support.</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                );
                                            }

                                            return (
                                                <div className="bg-white p-5 sm:p-6 rounded-xl border border-stone-200/80 shadow-xs">
                                                    <div className="relative flex flex-col md:flex-row justify-between items-start md:items-center gap-6 md:gap-4">
                                                        
                                                        {/* Progress bar line for Desktop */}
                                                        <div className="hidden md:block absolute top-5 left-[8%] right-[8%] h-[2px] bg-stone-100 -z-0">
                                                            <div 
                                                                className="h-full bg-stone-900 transition-all duration-500 ease-out" 
                                                                style={{ width: `${(activeStep / (steps.length - 1)) * 100}%` }}
                                                            />
                                                        </div>

                                                        {steps.map((step, idx) => {
                                                            const isCompleted = idx < activeStep || (activeStep === 3 && idx === 3);
                                                            const isCurrent = idx === activeStep && activeStep < 3;
                                                            const isPending = idx > activeStep;

                                                            return (
                                                                <div key={idx} className="flex md:flex-col items-center md:text-center gap-4 md:gap-3 flex-1 w-full relative z-10">
                                                                    {/* Mobile vertical line connecting step circles */}
                                                                    {idx > 0 && (
                                                                        <div className="md:hidden absolute -top-4 left-5 w-[2px] h-4 bg-stone-100" />
                                                                    )}

                                                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-all duration-300 shrink-0 ${
                                                                        isCompleted 
                                                                        ? 'bg-stone-900 border-stone-900 text-white shadow-xs' 
                                                                        : isCurrent 
                                                                        ? 'bg-white border-stone-900 text-stone-900 ring-4 ring-stone-100 shadow-sm scale-105' 
                                                                        : 'bg-white border-stone-200 text-stone-400'
                                                                    }`}>
                                                                        {isCompleted ? <FiCheck className="w-4 h-4" /> : step.icon}
                                                                    </div>
                                                                    
                                                                    <div className="space-y-0.5">
                                                                        <h4 className={`text-xs font-black tracking-tight leading-tight ${isCurrent ? 'text-stone-900' : isPending ? 'text-stone-400' : 'text-stone-700'}`}>
                                                                            {step.title}
                                                                        </h4>
                                                                        <p className="text-[10px] text-stone-400 font-medium leading-normal">{step.desc}</p>
                                                                    </div>
                                                                </div>
                                                            );
                                                        })}
                                                    </div>
                                                </div>
                                            );
                                        })()}

                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                                            
                                            {/* Items List */}
                                            <div className="space-y-4">
                                                <h4 className="text-xs font-black text-stone-900 uppercase tracking-widest border-b border-stone-200 pb-2">Order Items</h4>
                                                <div className="space-y-3">
                                                    {order.items.map((item, idx) => (
                                                        <div key={idx} className="flex items-center gap-3">
                                                            <img 
                                                                src={resolveItemImage(item)} 
                                                                alt={item.name}
                                                                className="w-10 h-10 rounded-md object-cover bg-stone-100 border border-stone-200 shrink-0"
                                                            />
                                                            <div className="flex-1 min-w-0">
                                                                <p className="text-xs font-bold text-stone-800 truncate">{item.name}</p>
                                                                <p className="text-[10px] font-medium text-stone-500 mt-0.5">Qty: {item.qty}</p>
                                                            </div>
                                                            <div className="text-right shrink-0">
                                                                <p className="text-xs font-bold text-stone-900 font-mono">${parseFloat(item.price).toFixed(2)}</p>
                                                            </div>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>

                                            {/* Details & Info */}
                                            <div className="space-y-6">
                                                {/* Delivery Info */}
                                                <div className="space-y-3">
                                                    <h4 className="text-xs font-black text-stone-900 uppercase tracking-widest border-b border-stone-200 pb-2">Delivery Details</h4>
                                                    <div className="bg-white p-3 rounded-lg border border-stone-200 shadow-sm space-y-2.5">
                                                        <div className="flex items-start gap-2 text-stone-600">
                                                            <FiMapPin className="w-4 h-4 text-stone-400 shrink-0 mt-0.5" />
                                                            <span className="text-xs font-medium leading-relaxed">{order.address}</span>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* Payment Info */}
                                                <div className="space-y-3">
                                                    <h4 className="text-xs font-black text-stone-900 uppercase tracking-widest border-b border-stone-200 pb-2">Payment Info</h4>
                                                    <div className="px-6 py-5 border border-stone-150 bg-stone-50 rounded-sm space-y-4">
                                                        <div className="flex items-center justify-between pb-4 border-b border-stone-200/60">
                                                            <div className="flex items-center gap-2 text-stone-600">
                                                                <FiCreditCard className="w-4 h-4 text-stone-400" />
                                                                <span className="text-xs font-bold">{order.paymentMethod === 'cod' ? 'Cash On Delivery' : order.paymentMethod}</span>
                                                            </div>
                                                            <span className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-sm ${
                                                                order.paymentStatus?.toLowerCase() === 'paid' 
                                                                ? 'bg-emerald-100 text-emerald-700' 
                                                                : 'bg-amber-100 text-amber-700'
                                                            }`}>
                                                                {order.paymentStatus}
                                                            </span>
                                                        </div>
                                                        
                                                        {/* Price Breakdown */}
                                                        <div className="space-y-2.5 pt-1">
                                                            {(() => {
                                                                const itemsSubtotal = order.items.reduce((acc, item) => acc + (parseFloat(item.price) * (item.qty || 1)), 0);
                                                                return (
                                                                    <>
                                                                        <div className="flex justify-between items-center text-xs font-semibold text-stone-600">
                                                                            <span>Subtotal</span>
                                                                            <span>US ${itemsSubtotal.toFixed(2)}</span>
                                                                        </div>
                                                                        {(order.couponCode || (order.discountAmount && parseFloat(order.discountAmount) > 0)) && (
                                                                            <div className="flex justify-between items-center text-xs font-bold text-[#E61E25]">
                                                                                <span className="flex items-center gap-1">
                                                                                    <FiTag className="w-3.5 h-3.5" />
                                                                                    {order.couponCode ? `Coupon (${order.couponCode})` : 'Discount'}
                                                                                </span>
                                                                                <span>- US ${parseFloat(order.discountAmount || '0').toFixed(2)}</span>
                                                                            </div>
                                                                        )}
                                                                    </>
                                                                );
                                                            })()}
                                                            {/* Assuming free shipping for now as it's not in the Order interface, but easily expandable */}
                                                            <div className="flex justify-between items-center text-xs font-semibold text-stone-600">
                                                                <span>Shipping</span>
                                                                <span>US $0.00</span>
                                                            </div>
                                                        </div>

                                                        <div className="flex justify-between items-center text-sm font-black text-stone-900 border-t border-stone-200/60 pt-3">
                                                            <span>Amount paid</span>
                                                            <span className="text-base font-black">US ${parseFloat(order.total).toFixed(2)}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                            </div>

                                        </div>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};


