import React, { useState, useEffect, useMemo, useRef } from 'react';
import type { StoreRow } from '@/api/owner/stores';
import { CardProduct } from './CardProduct';
import { FASHION_ROUTES } from '../../routes';
import { FiChevronLeft, FiChevronRight, FiZap } from 'react-icons/fi';

interface FlashDealsGridProps {
  deal: any;
  displayItems: any[];
  ownerUserId?: number | string;
  stores?: StoreRow;
  storeName: string;
  onNavigate?: (to: string) => void;
  addToCart: (item: any, qty?: number, size?: string, color?: string, price?: number) => void;
  favorites: Record<string, boolean>;
  toggleFavorite: (id: string, name: string) => void;
}

export const FlashDealsGrid: React.FC<FlashDealsGridProps> = ({
  deal,
  displayItems,
  ownerUserId,
  stores,
  storeName,
  onNavigate,
  addToCart,
  favorites,
  toggleFavorite,
}) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  const products = useMemo(() => deal.products || [], [deal.products]);

  const [showLeftArrow, setShowLeftArrow] = useState(false);
  const [showRightArrow, setShowRightArrow] = useState(true);
  const sliderRef = useRef<HTMLDivElement>(null);

  const handleScroll = () => {
    if (sliderRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = sliderRef.current;
      setShowLeftArrow(scrollLeft > 10);
      setShowRightArrow(scrollLeft + clientWidth < scrollWidth - 10);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (sliderRef.current) {
      const { clientWidth } = sliderRef.current;
      const scrollAmount = direction === 'left' ? -clientWidth * 0.75 : clientWidth * 0.75;
      sliderRef.current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      handleScroll();
    }, 150);
    return () => clearTimeout(timer);
  }, [products]);

  // Calculate remaining time and countdown tick
  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = +new Date(deal.end_date) - +new Date();
      let left = {
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0,
      };

      if (difference > 0) {
        left = {
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60),
        };
      }
      return left;
    };

    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, [deal.end_date]);

  // Calculate elapsed progress percentage
  const progressPercent = useMemo(() => {
    const start = +new Date(deal.start_date);
    const end = +new Date(deal.end_date);
    const now = +new Date();

    if (now >= end) return 100;
    if (now <= start) return 0;

    const total = end - start;
    const elapsed = now - start;
    return Math.min(Math.max((elapsed / total) * 100, 0), 100);
  }, [deal.start_date, deal.end_date]);

  return (
    <div className="p-6 sm:p-8 bg-[#F4F6FC] dark:bg-stone-900/40 rounded-[6px] border border-stone-200/50 dark:border-stone-850/60 shadow-3xs space-y-6 w-full text-left">
      {/* Header Bar: Title, Subtitle, and View All Link */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-stone-250/20">
        <div>
          <h2 className="text-base sm:text-lg font-black text-stone-900 dark:text-stone-100 tracking-wider uppercase font-sans flex items-center gap-1.5">
            <span className="text-[#E61E25]">⚡</span>
            {deal.title || 'Flash Deal'}
          </h2>
          <p className="text-stone-400 dark:text-stone-500 text-xs font-semibold mt-1">
            Hurry Up! The offer is limited. Grab while it lasts.
          </p>
        </div>

        <a
          href="/shop"
          onClick={(e) => {
            if (onNavigate) {
              e.preventDefault();
              const storeSlug = (stores?.store_name || storeName).replace(/\s+/g, '_');
              onNavigate(FASHION_ROUTES.getShop(ownerUserId, storeSlug));
            }
          }}
          className="text-[#E61E25] hover:text-red-700 dark:text-[#E61E25] dark:hover:text-red-400 text-[10px] font-black uppercase tracking-widest no-underline transition-colors cursor-pointer flex items-center shrink-0"
        >
          View All <span className="ml-1 text-xs">➔</span>
        </a>
      </div>

      {/* Main Content Layout */}
      <div className="flex flex-col lg:flex-row gap-6 items-stretch w-full">
        {/* Countdown Box */}
        <div className="w-full lg:w-[280px] shrink-0 bg-white dark:bg-stone-950 border border-stone-200/80 dark:border-stone-850 text-stone-900 dark:text-stone-100 p-6 rounded-[6px] flex flex-col justify-between select-none shadow-3xs relative overflow-hidden">
          {/* Soft background decor */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-stone-50 dark:bg-stone-900 rounded-full blur-xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-stone-50 dark:bg-stone-900 rounded-full blur-xl pointer-events-none" />

          {/* Top header of the box */}
          <div className="flex flex-col items-center text-center space-y-4 mt-2 relative z-10">
            <div className="flex items-center space-x-1.5 bg-stone-100 dark:bg-stone-900 px-2.5 py-1 rounded-full border border-stone-200 dark:border-stone-800">
              <span className="w-1.5 h-1.5 rounded-full bg-[#E61E25] animate-ping" />
              <span className="text-[9px] font-black uppercase tracking-widest text-stone-600 dark:text-stone-400 font-sans">
                Limited Time Offer
              </span>
            </div>

            {/* Lightning bolt / Promo graphic inside the box to balance empty space */}
            <div className="flex flex-col items-center space-y-1.5 py-2">
              <div className="w-12 h-12 rounded-full bg-amber-50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30 flex items-center justify-center shadow-xs animate-pulse">
                <FiZap className="w-6 h-6 text-amber-500 fill-amber-500" />
              </div>
              <h3 className="text-sm font-black uppercase tracking-wider font-sans text-stone-900 dark:text-stone-100 mt-1">
                FLASH SALE
              </h3>
              <p className="text-[10px] font-bold text-[#E61E25] uppercase tracking-widest">
                Up to 50% Off
              </p>
            </div>
          </div>

          {/* Middle: Timer boxes */}
          <div className="my-auto py-4 relative z-10">
            <div className="flex items-center justify-between gap-1.5">
              {/* Days */}
              <div className="flex-1 flex flex-col items-center">
                <div className="w-full py-3 bg-stone-50 dark:bg-stone-900 rounded-[4px] border border-stone-200/80 dark:border-stone-800 text-center font-bold text-lg sm:text-xl font-mono shadow-xs">
                  {String(timeLeft.days).padStart(2, '0')}
                </div>
                <span className="text-[8px] font-extrabold uppercase tracking-widest mt-1.5 text-stone-500 dark:text-stone-400">Days</span>
              </div>
              <span className="text-lg font-bold text-stone-400 dark:text-stone-600 pb-4">:</span>

              {/* Hours */}
              <div className="flex-1 flex flex-col items-center">
                <div className="w-full py-3 bg-stone-50 dark:bg-stone-900 rounded-[4px] border border-stone-200/80 dark:border-stone-800 text-center font-bold text-lg sm:text-xl font-mono shadow-xs">
                  {String(timeLeft.hours).padStart(2, '0')}
                </div>
                <span className="text-[8px] font-extrabold uppercase tracking-widest mt-1.5 text-stone-500 dark:text-stone-400">Hours</span>
              </div>
              <span className="text-lg font-bold text-stone-400 dark:text-stone-600 pb-4">:</span>

              {/* Minutes */}
              <div className="flex-1 flex flex-col items-center">
                <div className="w-full py-3 bg-stone-50 dark:bg-stone-900 rounded-[4px] border border-stone-200/80 dark:border-stone-800 text-center font-bold text-lg sm:text-xl font-mono shadow-xs">
                  {String(timeLeft.minutes).padStart(2, '0')}
                </div>
                <span className="text-[8px] font-extrabold uppercase tracking-widest mt-1.5 text-stone-500 dark:text-stone-400">Mins</span>
              </div>
              <span className="text-lg font-bold text-stone-400 dark:text-stone-600 pb-4">:</span>

              {/* Seconds */}
              <div className="flex-1 flex flex-col items-center">
                <div className="w-full py-3 bg-stone-50 dark:bg-stone-900 rounded-[4px] border border-stone-200/80 dark:border-stone-800 text-center font-bold text-lg sm:text-xl font-mono shadow-xs">
                  {String(timeLeft.seconds).padStart(2, '0')}
                </div>
                <span className="text-[8px] font-extrabold uppercase tracking-widest mt-1.5 text-stone-500 dark:text-stone-400">Secs</span>
              </div>
            </div>
          </div>

          {/* Bottom: Progress bar */}
          <div className="space-y-2.5 mb-2 relative z-10">
            <div className="w-full h-1.5 bg-stone-100 dark:bg-stone-900 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full transition-all duration-1000 shadow-sm"
                style={{ width: `${100 - progressPercent}%` }}
              />
            </div>
            <div className="flex justify-between text-[8px] font-extrabold uppercase tracking-widest text-stone-500 dark:text-stone-400">
              <span>Offer Progress</span>
              <span className="text-[#E61E25] font-black">{Math.round(100 - progressPercent)}% left</span>
            </div>
          </div>
        </div>

        {/* Product Cards Row Slider */}
        {products.length > 0 ? (
          <div className="relative group/slider flex-1 min-w-0">
            {/* Navigation Chevron Left */}
            {showLeftArrow && (
              <button
                onClick={() => scroll('left')}
                className="icon-scale-hover absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-stone-900/60 hover:bg-stone-900 text-white flex items-center justify-center transition-all duration-300 shadow-lg z-10 border-none cursor-pointer focus:outline-none"
              >
                <FiChevronLeft className="w-6 h-6" />
              </button>
            )}

            {/* Navigation Chevron Right */}
            {showRightArrow && (
              <button
                onClick={() => scroll('right')}
                className="icon-scale-hover absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-stone-900/60 hover:bg-stone-900 text-white flex items-center justify-center transition-all duration-300 shadow-lg z-10 border-none cursor-pointer focus:outline-none"
              >
                <FiChevronRight className="w-6 h-6" />
              </button>
            )}

            {/* Horizontal Slider Scrollable Row */}
            <div
              ref={sliderRef}
              onScroll={handleScroll}
              className="flex space-x-5 overflow-x-auto scrollbar-none scroll-smooth py-2 w-full"
              style={{
                msOverflowStyle: 'none',
                scrollbarWidth: 'none',
              }}
            >
              {products.map((product: any, idx: number) => {
                const isFavorited = !!favorites[String(product.id)];
                const fullProduct = displayItems.find((item) => item.id === product.id) || product;
                return (
                  <div
                    key={product.id}
                    className="w-[260px] sm:w-[290px] md:w-[305px] shrink-0 animate-fade-in-up"
                    style={{ animationDelay: `${idx * 50}ms` }}
                  >
                    <CardProduct
                      item={fullProduct}
                      ownerUserId={ownerUserId}
                      stores={stores}
                      storeName={storeName}
                      onNavigate={onNavigate}
                      addToCart={addToCart}
                      isFavorited={isFavorited}
                      onToggleFavorite={toggleFavorite}
                    />
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 border border-dashed border-stone-300 dark:border-stone-850 rounded-[4px]">
            <span className="text-2xl mb-2">🎁</span>
            <p className="text-xs font-bold text-stone-500 uppercase tracking-wide">
              No products active in this deal
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

