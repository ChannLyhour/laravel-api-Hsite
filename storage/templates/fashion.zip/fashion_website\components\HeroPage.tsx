import React, { useState, useEffect, useMemo } from 'react';
import { FiChevronLeft, FiChevronRight, FiArrowRight } from 'react-icons/fi';
import '../styles/animation.css';
import type { HeroPageProps } from '../types';
import { resolveImageUrl } from '../utils/imageUtils';
import { FASHION_ROUTES } from '../routes';


export const HeroPage: React.FC<HeroPageProps> = ({
  storeName = 'Prime Store',
  stores,
  onNavigate,
  ownerUserId,
  banners = [],
}) => {
  const storeSlug = (stores?.store_name || storeName).replace(/\s+/g, '_');
  const [currentSlide, setCurrentSlide] = useState(0);
  const [animating, setAnimating] = useState(false);

  const slides = useMemo(() => {
    return banners.map((b, idx) => {
      const hasContent = !!(b.title || b.description);
      return {
        tagline: hasContent ? 'PROMOTIONAL' : '',
        title: b.title || '',
        desc: b.description || '',
        image1: resolveImageUrl(b.image),
        badge: hasContent ? (idx % 2 === 0 ? "Featured" : "Trending") : '',
        hasContent,
      };
    });
  }, [banners]);

  useEffect(() => {
    setCurrentSlide(0);
  }, [slides]);

  useEffect(() => {
    if (slides.length === 0) return;
    const timer = setInterval(() => {
      handleNext();
    }, 8000);
    return () => clearInterval(timer);
  }, [currentSlide, slides.length]);

  const handleNext = () => {
    if (animating || slides.length === 0) return;
    setAnimating(true);
    setCurrentSlide(prev => (prev + 1) % slides.length);
    setTimeout(() => setAnimating(false), 800);
  };

  const handlePrev = () => {
    if (animating || slides.length === 0) return;
    setAnimating(true);
    setCurrentSlide(prev => (prev - 1 + slides.length) % slides.length);
    setTimeout(() => setAnimating(false), 800);
  };

  if (slides.length === 0) return null;

  const activeSlide = slides[currentSlide];

  return (
    <section className="relative py-4 sm:py-8 bg-white font-sans overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div 
          onClick={() => {
            if (!activeSlide.hasContent && onNavigate) {
              onNavigate(FASHION_ROUTES.getShop(ownerUserId || '', storeSlug));
            }
          }}
          className={`relative h-[300px] sm:h-[450px] lg:h-[420px] w-full rounded-md sm:rounded-md overflow-hidden group/slider shadow-2xl bg-stone-100 border border-stone-200/20 ${
            !activeSlide.hasContent ? 'cursor-pointer hover:shadow-3xl transition-shadow duration-300' : ''
          }`}
        >


          {/* Background Images Layer */}
          <div className="absolute inset-0 z-0 overflow-hidden">
            <div 
              key={currentSlide}
              className="w-full h-full animate-ken-burns"
            >
              <img
                src={activeSlide.image1}
                alt={activeSlide.title || 'Banner'}
                className="w-full h-full object-cover object-center"
              />
            </div>
            {/* Ambient dark gradient overlay to guarantee text legibility */}
            {activeSlide.hasContent && (
              <div className="absolute inset-0 bg-gradient-to-r from-stone-950/85 via-stone-950/45 to-transparent pointer-events-none" />
            )}
          </div>

          {/* Floating Accent (Next Preview) */}


          {/* Content Layer */}
          {activeSlide.hasContent && (
            <div className="relative z-10 h-full flex flex-col justify-center items-start px-8 sm:px-16 lg:px-24 max-w-4xl">
              {/* Badge */}
              <div className={`mb-4 sm:mb-6 transition-all duration-1000 ease-out ${animating ? 'translate-y-6 opacity-0' : 'translate-y-0 opacity-100'}`}>
                <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-stone-900 border border-stone-800 rounded-full text-white text-[9px] font-black uppercase tracking-[0.2em]">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#E61E25] shadow-[0_0_8px_#E61E25] animate-pulse" />
                  {activeSlide.badge}
                </span>
              </div>

              {/* Tagline */}
              <p className={`text-[#E61E25] text-[10px] sm:text-xs font-black tracking-[0.3em] uppercase mb-3 transition-all duration-1000 delay-100 ease-out ${animating ? 'translate-y-6 opacity-0' : 'translate-y-0 opacity-100'}`}>
                {activeSlide.tagline}
              </p>

              {/* Title */}
              <h1 className={`text-3xl sm:text-5xl lg:text-6xl font-serif text-white leading-[1.15] mb-6 transition-all duration-1000 delay-200 ease-out ${animating ? 'translate-y-10 opacity-0' : 'translate-y-0 opacity-100'}`}>
                {activeSlide.title.split(' ').map((word, i) => (
                  <span key={i} className="block first:italic last:text-white/40">{word}</span>
                ))}
              </h1>

              {/* Description */}
              <p className={`text-white/90 text-xs sm:text-sm lg:text-base max-w-md mb-8 leading-relaxed transition-all duration-1000 delay-300 ease-out ${animating ? 'translate-y-6 opacity-0' : 'translate-y-0 opacity-100'}`}>
                {activeSlide.desc}
              </p>

              {/* CTA */}
              <div className={`transition-all duration-1000 delay-400 ease-out ${animating ? 'translate-y-6 opacity-0' : 'translate-y-0 opacity-100'}`}>
                <button
                  onClick={() => {
                    if (onNavigate) {
                      onNavigate(FASHION_ROUTES.getShop(ownerUserId || '', storeSlug));
                    }
                  }}
                  className="group relative flex items-center gap-4 bg-white text-stone-950 px-5 py-2.5 text-[10px] font-black uppercase tracking-[0.2em] hover:text-white transition-all duration-700 rounded-sm shadow-xl overflow-hidden cursor-pointer btn-shine-swipe"
                >
                  <span className="relative z-10">Discover Collection</span>
                  <FiArrowRight className="relative z-10 w-4 h-4 transition-transform duration-700 group-hover:translate-x-2" />
                  <div className="absolute inset-0 bg-stone-950 translate-x-[-100%] group-hover:translate-x-0 transition-transform duration-700 ease-in-out" />
                </button>
              </div>
            </div>
          )}

          {/* Navigation Controls */}
          {slides.length > 1 && (
            <>
              {/* Pagination Dots Capsule */}
              <div 
                onClick={(e) => e.stopPropagation()}
                className="absolute bottom-6 left-6 z-20 flex items-center gap-2.5 px-4 py-2 rounded-full bg-stone-950/45 backdrop-blur-md border border-white/10 shadow-lg select-none"
              >
                {slides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      if (animating || currentSlide === index) return;
                      setAnimating(true);
                      setCurrentSlide(index);
                      setTimeout(() => setAnimating(false), 800);
                    }}
                    className={`rounded-full transition-all duration-500 cursor-pointer border-none ${
                      currentSlide === index ? 'w-7 bg-[#E61E25] h-1.5' : 'w-1.5 h-1.5 bg-white/40 hover:bg-white/70'
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>

              {/* Navigation Arrows Capsule */}
              <div 
                onClick={(e) => e.stopPropagation()}
                className="absolute bottom-6 right-6 z-20 flex items-center gap-1 p-1 rounded-full bg-stone-950/45 backdrop-blur-md border border-white/10 shadow-lg select-none"
              >
                <button
                  onClick={handlePrev}
                  className="w-9 h-9 flex items-center justify-center rounded-full text-white/80 hover:text-white hover:bg-white/10 active:scale-90 transition-all duration-300 cursor-pointer focus:outline-none border-none bg-transparent"
                  aria-label="Previous slide"
                >
                  <FiChevronLeft className="w-5 h-5" />
                </button>
                <div className="w-[1px] h-4 bg-white/15 self-center" />
                <button
                  onClick={handleNext}
                  className="w-9 h-9 flex items-center justify-center rounded-full text-white/80 hover:text-white hover:bg-white/10 active:scale-90 transition-all duration-300 cursor-pointer focus:outline-none border-none bg-transparent"
                  aria-label="Next slide"
                >
                  <FiChevronRight className="w-5 h-5" />
                </button>
              </div>
            </>
          )}

        </div>
      </div>
    </section>
  );
};
