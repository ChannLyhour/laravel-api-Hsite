import React, { useState, useEffect } from 'react';
import { FiMapPin, FiPhone, FiMail } from 'react-icons/fi';
import { FaFacebookF, FaTelegramPlane, FaTiktok, FaInstagram, FaYoutube, FaWhatsapp, FaTwitter, FaLinkedinIn } from 'react-icons/fa';
import { storesService } from '@/api/owner/stores';
import type { StoreRow } from '@/api/owner/stores';
import { socialMediaService } from '@/api/owner/socialMedia';
import type { SocialMediaRow } from '@/api/owner/socialMedia';
import '../styles/animation.css';
import type { FooterPageProps } from '../types';

export const FooterPage: React.FC<FooterPageProps> = ({
  storeName = 'Prime Store',
  stores,
  ownerUserId,
}) => {
  const [storeInfo, setStoreInfo] = useState<StoreRow | null>(stores || null);
  const [socials, setSocials] = useState<SocialMediaRow[]>([]);

  useEffect(() => {
    if (!ownerUserId) {
      if (stores) {
        setStoreInfo(stores);
      }
      return;
    }

    const fetchData = async () => {
      try {
        const [storeData, socialData] = await Promise.all([
          storesService.getStoreByOwner(ownerUserId),
          socialMediaService.getPublicSocials(ownerUserId)
        ]);
        setStoreInfo(storeData);
        setSocials(socialData);
      } catch (err) {
        console.error('Failed to fetch data in fashion footer:', err);
        if (stores) {
          setStoreInfo(stores);
        }
      }
    };
    fetchData();
  }, [stores, ownerUserId]);

  const formatSocialUrl = (url?: string) => {
    if (!url || url === '#' || url === '---') return '';
    if (url.startsWith('http://') || url.startsWith('https://')) return url;
    return `https://${url}`;
  };

  const getSocialIcon = (name: string) => {
    const n = name.toLowerCase();
    if (n.includes('facebook')) return <FaFacebookF className="w-3.5 h-3.5 text-[#1877F2]" />;
    if (n.includes('telegram')) return <FaTelegramPlane className="w-3.5 h-3.5 text-[#37aee2]" />;
    if (n.includes('tiktok')) return <FaTiktok className="w-3.5 h-3.5 text-black" />;
    if (n.includes('instagram')) return <FaInstagram className="w-3.5 h-3.5 text-[#E4405F]" />;
    if (n.includes('youtube')) return <FaYoutube className="w-3.5 h-3.5 text-[#CD201F]" />;
    if (n.includes('whatsapp')) return <FaWhatsapp className="w-3.5 h-3.5 text-[#25D366]" />;
    if (n.includes('x') || n.includes('twitter')) return <FaTwitter className="w-3.5 h-3.5 text-[#1DA1F2]" />;
    if (n.includes('linkedin')) return <FaLinkedinIn className="w-3.5 h-3.5 text-[#0077B5]" />;
    return null;
  };

  return (
    <footer className="bg-white text-stone-500 pt-16 pb-10 mt-auto border-t border-stone-200/60 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Column 1: Brand & Bio */}
          <div className="space-y-4 text-left">
            <span className="font-sans font-black text-xl text-stone-900 uppercase tracking-widest block transition-all duration-300 hover:text-[#E61E25] cursor-default">
              {storeInfo?.store_name || storeName}
            </span>
            <p className="text-xs leading-relaxed text-stone-500 font-medium">
              Premium haute-couture boutique specializing in minimalist organic clothing, linen collections,
              and handcrafted style lookbooks.
            </p>

            {/* Dynamic Social Icons */}
            <div className="flex items-center space-x-3 pt-2">
              {socials.map((social) => (
                <a
                  key={social.id}
                  href={formatSocialUrl(social.link)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-8 h-8 rounded-full border border-stone-200 hover:border-stone-400 text-stone-500 hover:text-stone-900 flex items-center justify-center transition-all duration-300"
                  title={social.name}
                >
                  {getSocialIcon(social.name)}
                </a>
              ))}
            </div>
          </div>

          {/* Column 2: Customer Service */}
          <div className="space-y-4 text-left">
            <h4 className="text-stone-900 font-black text-xs uppercase tracking-wider">Customer Care</h4>
            <ul className="space-y-2.5 text-xs font-semibold list-none p-0 m-0">
              <li>
                <a href="#help" className="footer-link-draw text-stone-500 no-underline">
                  Help Center & FAQ
                </a>
              </li>
              <li>
                <a href="#returns" className="footer-link-draw text-stone-500 no-underline">
                  Returns & Exchanges
                </a>
              </li>
              <li>
                <a href="#shipping" className="footer-link-draw text-stone-500 no-underline">
                  Shipping Guide
                </a>
              </li>
              <li>
                <a href="#sizing" className="footer-link-draw text-stone-500 no-underline">
                  Size Guide Chart
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Quick Links */}
          <div className="space-y-4 text-left">
            <h4 className="text-stone-900 font-black text-xs uppercase tracking-wider">The {storeInfo?.store_name || storeName}</h4>
            <ul className="space-y-2.5 text-xs font-semibold list-none p-0 m-0">
              <li>
                <a href="#new" className="footer-link-draw text-stone-500 no-underline">
                  New Arrivals
                </a>
              </li>
              <li>
                <a href="#lookbook" className="footer-link-draw text-stone-500 no-underline">
                  Runway Lookbooks
                </a>
              </li>
              <li>
                <a href="#sustainability" className="footer-link-draw text-stone-500 no-underline">
                  Organic Fabric Story
                </a>
              </li>
              <li>
                <a href="#giftcards" className="footer-link-draw text-stone-500 no-underline">
                  Boutique Gift Cards
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact / Hub */}
          <div className="space-y-4 text-left">
            <h4 className="text-stone-900 font-black text-xs uppercase tracking-wider">Contant Me</h4>
            <div className="space-y-3 text-xs font-semibold">
              <p className="hover-translate-r flex items-start gap-2.5 m-0 cursor-default">
                <FiMapPin className="text-stone-400 shrink-0 mt-0.5" />
                <span className="text-stone-600">
                  {storeInfo?.store_address && storeInfo.store_address !== '---'
                    ? storeInfo.store_address
                    : '---'}
                </span>
              </p>
              <p className="hover-translate-r flex items-center gap-2.5 m-0 cursor-default">
                <FiPhone className="text-stone-400 shrink-0" />
                <span className="text-stone-600">
                  {storeInfo?.store_phone && storeInfo.store_phone !== '---'
                    ? storeInfo.store_phone
                    : '---'}
                </span>
              </p>
              <p className="hover-translate-r flex items-center gap-2.5 m-0 cursor-default">
                <FiMail className="text-stone-400 shrink-0" />
                <span className="text-stone-600">
                  {storeInfo?.store_email && storeInfo.store_email !== '---'
                    ? storeInfo.store_email
                    : '---'}
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Copyright Row */}
        <div className="pt-8 border-t border-stone-200/80 flex flex-col sm:flex-row justify-between items-center text-3xs font-black tracking-widest text-stone-500 uppercase gap-4">
          <span>
            &copy; {new Date().getFullYear()} {storeInfo?.store_name || storeName}. All collections
            limited.
          </span>
          {/* website Built By: Chann Lyhour or VHsite */}
          {/* <span>BiteFlow Style Runway Boutique</span> */}
        </div>
      </div>
    </footer>
  );
};
