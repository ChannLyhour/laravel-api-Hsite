import React, { useEffect, useState } from 'react';
import { categoriesService, type ProductVariant } from '@/api/owner/categories';
import type { Root2 } from '@/api/owner/categories';
import { ApiError, API_BASE_URL } from '@/api/client';
import {
  FiTrendingUp, FiInfo,
  FiMinus, FiPlus, FiTrash2
} from 'react-icons/fi';
import { toast } from 'react-hot-toast';
import { Store_setting } from '@/api/owner/stores';
import '@/pages/owner_manage/style/font.css';

import type { SettingResponse } from '@/api/setting';
import { themes } from '@/pages/owner_manage/templete_website/themes';

interface MenuItemPageProps {
  ownerUserId?: number | string;
  profile?: any;
  onNavigate?: (to: string) => void;
  storeName?: string;
  locale?: 'en' | 'km';
  settings?: SettingResponse['settings'] | null;
}

interface CartItem {
  id: string;
  item: Root2;
  qty: number;
  selectedVariant?: ProductVariant;
}

export const MenuItemPage: React.FC<MenuItemPageProps> = ({ ownerUserId, storeName, locale, settings }) => {
  const activeTheme = themes[settings?.website_theme || 'default'] || themes.default;
  const isDarkTheme = (settings?.website_theme || '').startsWith('minimal_dark') || settings?.website_theme === 'glass_gradient' || settings?.website_theme === 'electronic';
  const [topSellingItems, setTopSellingItems] = useState<Root2[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Cart States
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orderMethod, setOrderMethod] = useState<'delivery' | 'pickup'>('delivery');

  // Variant state
  const [selectedVariants, setSelectedVariants] = useState<Record<number, ProductVariant>>({});

  // Localization helper
  const getTranslation = (item: Root2, currentLocale?: 'en' | 'km') => {
    const active = currentLocale || 'en';
    const trans = item.translations?.find(t => t.locale === active);
    return {
      name: trans?.name || item.name,
      description: trans?.description || item.description
    };
  };

  // Variant helpers
  const getActiveVariant = (item: Root2): ProductVariant | undefined => {
    if (!item.variants || item.variants.length === 0) return undefined;
    return selectedVariants[item.id] || item.variants[0];
  };

  const getActiveImage = (item: Root2, activeVariant?: ProductVariant): string => {
    if (activeVariant && item.images && item.images.length > 0) {
      const variantImage = item.images.find(img => img.product_variant_id === activeVariant.id);
      if (variantImage) {
        let imagePath = variantImage.image as any;
        if (Array.isArray(imagePath)) {
          imagePath = imagePath[0];
        }
        if (typeof imagePath === 'string') {
          imagePath = imagePath.trim();
          if (imagePath.startsWith('[') || imagePath.startsWith('{')) {
            try {
              const parsed = JSON.parse(imagePath);
              if (Array.isArray(parsed)) {
                imagePath = parsed[0];
              } else if (parsed && typeof parsed === 'object') {
                imagePath = Object.values(parsed)[0];
              }
            } catch (e) { }
          }
        } else if (imagePath && typeof imagePath === 'object') {
          imagePath = Object.values(imagePath)[0] || '';
        }

        if (typeof imagePath === 'string' && imagePath.trim()) {
          const cleanPath = imagePath.trim();
          if (cleanPath.startsWith('http://') || cleanPath.startsWith('https://') || cleanPath.startsWith('data:') || cleanPath.startsWith('blob:')) {
            return cleanPath;
          }
          const serverBase = API_BASE_URL.replace(/\/api$/, '');
          const cleanPathNoSlash = cleanPath.replace(/^\//, '');
          if (cleanPathNoSlash.startsWith('uploads/') || cleanPathNoSlash.startsWith('static/')) {
            return `${serverBase}/${cleanPathNoSlash}`;
          }
          return `${serverBase}/uploads/${cleanPathNoSlash}`;
        }
      }
    }
    return item.display_image || 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=500&q=80';
  };

  const getActivePrice = (item: Root2, activeVariant?: ProductVariant): number => {
    if (activeVariant) {
      return parseFloat(activeVariant.retail_price);
    }
    return parseFloat(item.price);
  };

  const getVariantLabel = (variantOrSku: any, baseSku?: string) => {
    if (!variantOrSku) return 'Standard';
    if (typeof variantOrSku === 'object') {
      const attributeValues = variantOrSku.attribute_values;
      if (attributeValues && attributeValues.length > 0) {
        return attributeValues.map((av: any) => {
          const attrName = av.attribute?.name || '';
          const attrVal = av.value?.split('|')[0] || '';
          if (attrName && attrVal) {
            return `${attrName}: ${attrVal}`;
          }
          return attrVal || attrName;
        }).join(', ');
      }
      variantOrSku = variantOrSku.variant_sku;
    }
    const sku = String(variantOrSku);
    if (baseSku && sku.startsWith(baseSku)) {
      const suffix = sku.replace(baseSku, '').replace(/^-/, '');
      if (suffix) return suffix.replace(/-/g, ' ');
    }
    const parts = sku.split('-');
    if (parts.length > 2) {
      return parts.slice(2).join(' ');
    }
    return sku;
  };

  // Load top-selling items from the database
  useEffect(() => {
    const fetchTopSelling = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch top 8 best-selling menu items to construct our grids
        const topSellingData = await categoriesService.getTopSelling(8, ownerUserId);
        setTopSellingItems(topSellingData || []);
      } catch (err) {
        if (err instanceof ApiError) {
          setError(err.details.message);
        } else {
          setError('Failed to connect to backend server. Please verify your FastAPI API is running.');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchTopSelling();
  }, [ownerUserId]);

  // Cart Handlers
  const addToCart = (item: Root2) => {
    const activeVariant = getActiveVariant(item);
    const cartItemId = activeVariant
      ? `${item.id}-${activeVariant.variant_sku}`
      : String(item.id);

    const { name: displayName } = getTranslation(item, locale);
    const variantLabel = activeVariant ? ` (${getVariantLabel(activeVariant, item.sku)})` : '';

    setCart(prev => {
      const existing = prev.find(ci => ci.id === cartItemId);
      if (existing) {
        toast.success(`Incremented quantity for ${displayName}${variantLabel}!`);
        return prev.map(ci => ci.id === cartItemId ? { ...ci, qty: ci.qty + 1 } : ci);
      }
      toast.success(`Added ${displayName}${variantLabel} to cart!`);
      return [...prev, { id: cartItemId, item, qty: 1, selectedVariant: activeVariant }];
    });
  };

  const updateQty = (id: string, delta: number) => {
    setCart(prev => {
      return prev.map(ci => {
        if (ci.id === id) {
          const nextQty = ci.qty + delta;
          return { ...ci, qty: Math.max(1, nextQty) };
        }
        return ci;
      });
    });
  };

  const removeFromCart = (id: string, name: string) => {
    setCart(prev => prev.filter(ci => ci.id !== id));
    toast.error(`Removed ${name} from cart.`);
  };

  // Subtotal Calculations
  const subtotal = cart.reduce((sum, ci) => {
    const price = ci.selectedVariant
      ? parseFloat(ci.selectedVariant.retail_price)
      : parseFloat(ci.item.price);
    return sum + (price * ci.qty);
  }, 0);

  const dynamicSettings = Store_setting();
  const shippingFee = settings?.shipping_fee ? parseFloat(settings.shipping_fee) : (dynamicSettings?.shipping_fee ? parseFloat(dynamicSettings.shipping_fee) : 0);
  const threshold = settings?.free_shipping_threshold ? parseFloat(settings.free_shipping_threshold) : (dynamicSettings?.free_shipping_threshold ? parseFloat(dynamicSettings.free_shipping_threshold) : 0);

  const deliveryFee = orderMethod === 'delivery' && subtotal > 0 ? ((threshold > 0 && subtotal > threshold) ? 0 : shippingFee) : 0;
  const total = subtotal + deliveryFee;

  // Split items into Popular (first 4) and Special Offers (remaining)
  const popularItems = topSellingItems.slice(0, 4);
  const specialOffers = topSellingItems.slice(4);

  return (
    <section id="menu" className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 font-kuntomruy">

      {/* Split Page Grid: Main grid left + Cart sidebar right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">

        {/* ── Left Column: Main Food Menu Listing ─────────────────── */}
        <div className="lg:col-span-2 space-y-10">

          {/* Header */}
          <div className="space-y-3 mb-6 animate-fade-in">
            <span className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-[5px] text-[10px] font-black uppercase tracking-wider ${activeTheme.badgeBg} ${activeTheme.badgeText}`}>
              <FiTrendingUp />
              <span>Top Culinary Choices</span>
            </span>
            <h2 className={`text-2xl sm:text-3xl tracking-tight ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>
              {storeName ? `${storeName}'s Best Selling Delicacies` : 'Our Best Selling Delicacies'}
            </h2>
            <p className={`text-xs sm:text-sm max-w-xl font-medium leading-relaxed ${isDarkTheme ? 'text-slate-400 font-normal' : 'text-slate-500'}`}>
              Explore our top-selling dishes curated by local Master Chefs using organic, local farm ingredients.
            </p>
          </div>

          {/* Loading Spinner */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-20 space-y-4 animate-fade-in">
              <svg className={`animate-spin h-10 w-10 ${activeTheme.primaryText}`} fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <p className="text-slate-400 font-bold text-xs">Loading items from database...</p>
            </div>
          )}

          {/* Error Alert */}
          {error && (
            <div className="p-5 bg-rose-50 border border-rose-100 rounded-[5px] flex items-start space-x-3 text-rose-800 text-xs animate-slide-up">
              <FiInfo className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              <div className="font-semibold leading-relaxed">
                {error}
              </div>
            </div>
          )}

          {/* Empty State */}
          {!loading && !error && topSellingItems.length === 0 && (
            <div className="text-center py-16 space-y-2 bg-slate-50 rounded-[5px] border border-slate-100 animate-fade-in">
              <span className="text-4xl block">🥗</span>
              <h4 className="font-extrabold text-slate-800">No dishes available at this time</h4>
              <p className="text-slate-400 text-xs font-medium">Please add items through your admin panel dashboard.</p>
            </div>
          )}

          {/* ── Section 1: Popular Dishes ────────────────────── */}
          {!loading && !error && popularItems.length > 0 && (
            <div className="space-y-5 animate-fade-in">
              <div>
                <h3 className={`text-lg flex items-center space-x-1.5 ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-800'}`}>
                  <span>🔥</span>
                  <span>Popular</span>
                </h3>
                <p className="text-slate-400 text-2xs font-semibold mt-0.5">Most ordered right now.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {popularItems.map(item => {
                  const { name: displayName, description: displayDescription } = getTranslation(item, locale);
                  const activeVariant = getActiveVariant(item);
                  const basePrice = getActivePrice(item, activeVariant);
                  const activeImage = getActiveImage(item, activeVariant);

                  // Custom visual helper: simulate original price crossed out if ID is odd
                  const isDiscounted = item.id % 2 !== 0;
                  const originalPrice = isDiscounted ? (basePrice * 1.2).toFixed(2) : null;

                  return (
                    <div
                      key={item.id}
                      className={`rounded-[5px] p-4 flex flex-col justify-between gap-4 transition-all duration-300 relative group border ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.shadowClass} ${activeTheme.glassClass || ''}`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        {/* Details Left */}
                        <div className="flex-grow space-y-2">
                          <h4 className={`text-sm sm:text-base leading-tight group-hover:${activeTheme.primaryText} transition-colors ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900 font-extrabold'}`}>
                            {displayName}
                          </h4>

                          {/* Price line with crossed out discount if applicable */}
                          <div className="flex items-center space-x-2 text-xs font-black">
                            <span className={`font-black ${activeTheme.primaryText}`}>${basePrice.toFixed(2)}</span>
                            {originalPrice && (
                              <span className="text-slate-400 font-semibold line-through text-[10px] sm:text-xs">
                                ${originalPrice}
                              </span>
                            )}
                          </div>

                          <p className="text-slate-400 text-2xs leading-relaxed line-clamp-2 font-medium">
                            {displayDescription || 'Experience the authentic culinary flavor curated special by our kitchen staff.'}
                          </p>
                        </div>

                        {/* Picture Right */}
                        <div className="relative shrink-0 w-25 h-25 sm:w-24 sm:h-24 overflow-hidden rounded-[5px] border border-slate-200/40 shadow-3xs bg-slate-50">
                          <img
                            src={activeImage}
                            alt={displayName}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=500&q=80';
                            }}
                          />

                          {/* Action round plus button */}
                          <button
                            onClick={() => addToCart(item)}
                            className="absolute bottom-1.5 right-1.5 w-6.5 h-6.5 bg-white hover:bg-slate-100 rounded-[5px] flex items-center justify-center text-slate-800 border border-slate-200/60 shadow-xs font-black transition-all active:scale-90 cursor-pointer text-xs"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Pill Selector for Variants */}
                      {item.variants && item.variants.length > 1 && (
                        <div className="mt-2 space-y-1 animate-fade-in border-t border-slate-50 pt-2">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Options:</span>
                          <div className="flex flex-wrap gap-1">
                            {item.variants.map((v) => {
                              const isSelected = activeVariant?.variant_sku === v.variant_sku;
                              return (
                                <button
                                  key={v.variant_sku}
                                  onClick={() => setSelectedVariants(prev => ({ ...prev, [item.id]: v }))}
                                  className={`px-2 py-0.5 rounded-[5px] text-[10px] font-bold border transition-all cursor-pointer ${isSelected
                                      ? `${activeTheme.primaryBg} border-transparent text-white shadow-2xs font-extrabold`
                                      : 'bg-slate-50 border-slate-200/60 text-slate-600 hover:bg-slate-100 hover:border-slate-300'
                                    }`}
                                >
                                  {getVariantLabel(v, item.sku)} - ${parseFloat(v.retail_price).toFixed(0)}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Fire / Likes tag at bottom left */}
                      <div className={`flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-[5px] w-max mt-2 border ${activeTheme.badgeBg} ${activeTheme.badgeText}`}>
                        <span>🔥</span>
                        <span>Popular</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ── Section 2: Special Offers ────────────────────── */}
          {!loading && !error && specialOffers.length > 0 && (
            <div className="space-y-5 animate-fade-in pt-4">
              <div>
                <h3 className={`text-lg flex items-center space-x-1.5 ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-800'}`}>
                  <span>🎁</span>
                  <span>Special Offer</span>
                </h3>
                <p className="text-slate-400 text-2xs font-semibold mt-0.5">Chef's custom deals.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                {specialOffers.map(item => {
                  const { name: displayName, description: displayDescription } = getTranslation(item, locale);
                  const activeVariant = getActiveVariant(item);
                  const basePrice = getActivePrice(item, activeVariant);
                  const activeImage = getActiveImage(item, activeVariant);

                  const originalPrice = (basePrice * 1.25).toFixed(2);

                  return (
                    <div
                      key={item.id}
                      className={`rounded-[5px] p-4 flex flex-col justify-between gap-4 transition-all duration-300 relative group border ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.shadowClass} ${activeTheme.glassClass || ''}`}
                    >
                      <div className="flex items-start justify-between gap-4">
                        {/* Details Left */}
                        <div className="flex-grow space-y-2">
                          <h4 className={`text-sm sm:text-base leading-tight group-hover:${activeTheme.primaryText} transition-colors ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900 font-extrabold'}`}>
                            {displayName}
                          </h4>

                          {/* Price line with crossed out discount */}
                          <div className="flex items-center space-x-2 text-xs font-black">
                            <span className={`font-black ${activeTheme.primaryText}`}>${basePrice.toFixed(2)}</span>
                            <span className="text-slate-400 font-semibold line-through text-[10px] sm:text-xs">
                              ${originalPrice}
                            </span>
                          </div>

                          <p className="text-slate-400 text-2xs leading-relaxed line-clamp-2 font-medium">
                            {displayDescription || 'Enjoy our hassle-free gourmet sensation custom packed to suit your tastes.'}
                          </p>
                        </div>

                        {/* Picture Right */}
                        <div className="relative shrink-0 w-[35px] h-[35px] overflow-hidden rounded-[5px] border border-slate-200/40 shadow-3xs bg-slate-50">
                          <img
                            src={activeImage}
                            alt={displayName}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=500&q=80';
                            }}
                          />

                          {/* Action round plus button */}
                          <button
                            onClick={() => addToCart(item)}
                            className="absolute bottom-1.5 right-1.5 w-6.5 h-6.5 bg-white hover:bg-slate-100 rounded-[5px] flex items-center justify-center text-slate-800 border border-slate-200/60 shadow-xs font-black transition-all active:scale-90 cursor-pointer text-xs"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      {/* Pill Selector for Variants */}
                      {item.variants && item.variants.length > 1 && (
                        <div className="mt-2 space-y-1 animate-fade-in border-t border-slate-50 pt-2">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">Options:</span>
                          <div className="flex flex-wrap gap-1">
                            {item.variants.map((v) => {
                              const isSelected = activeVariant?.variant_sku === v.variant_sku;
                              return (
                                <button
                                  key={v.variant_sku}
                                  onClick={() => setSelectedVariants(prev => ({ ...prev, [item.id]: v }))}
                                  className={`px-2 py-0.5 rounded-[5px] text-[10px] font-bold border transition-all cursor-pointer ${isSelected
                                      ? `${activeTheme.primaryBg} border-transparent text-white shadow-2xs font-extrabold`
                                      : 'bg-slate-50 border-slate-200/60 text-slate-600 hover:bg-slate-100 hover:border-slate-300'
                                    }`}
                                >
                                  {getVariantLabel(v, item.sku)} - ${parseFloat(v.retail_price).toFixed(0)}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      <div className={`flex items-center gap-1 text-[10px] font-black px-2 py-0.5 rounded-[5px] w-max mt-2 border ${activeTheme.badgeBg} ${activeTheme.badgeText}`}>
                        <span>⚡</span>
                        <span>Special Deal</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* ── Right Column: Sticky Cart Sidebar ─────────────────── */}
        <div className={`lg:col-span-1 border rounded-[5px] p-5 sticky top-24 space-y-6 ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.shadowClass} ${activeTheme.glassClass || ''}`}>

          {/* Toggle Delivery vs Pick-up */}
          <div className={`flex p-1 rounded-[5px] border ${isDarkTheme ? 'bg-slate-950/60 border-slate-800/80' : 'bg-slate-50 border-slate-100'}`}>
            <button
              onClick={() => setOrderMethod('delivery')}
              className={`flex-1 py-2 text-center text-xs font-extrabold rounded-[5px] transition-all cursor-pointer ${orderMethod === 'delivery'
                  ? `${isDarkTheme ? 'bg-slate-800 text-white border-slate-700/80 shadow-xs' : 'bg-white text-slate-800 border-slate-200 shadow-2xs'} border`
                  : 'text-slate-400 hover:text-slate-655'
                }`}
            >
              Delivery
            </button>
            <button
              onClick={() => setOrderMethod('pickup')}
              className={`flex-1 py-2 text-center text-xs font-extrabold rounded-[5px] transition-all cursor-pointer ${orderMethod === 'pickup'
                  ? `${isDarkTheme ? 'bg-slate-800 text-white border-slate-700/80 shadow-xs' : 'bg-white text-slate-800 border-slate-200 shadow-2xs'} border`
                  : 'text-slate-400 hover:text-slate-655'
                }`}
            >
              Pick-up
            </button>
          </div>

          {/* Active Cart Items or Empty state */}
          {cart.length > 0 ? (
            <div className="space-y-4 max-h-[280px] overflow-y-auto pr-1">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Your Cart Items
              </h4>

              <div className={`divide-y ${isDarkTheme ? 'divide-slate-800/40' : 'divide-slate-50'} space-y-3`}>
                {cart.map(ci => {
                  const { name: displayName } = getTranslation(ci.item, locale);
                  const activePrice = ci.selectedVariant
                    ? parseFloat(ci.selectedVariant.retail_price)
                    : parseFloat(ci.item.price);
                  const variantSuffix = ci.selectedVariant
                    ? ` (${getVariantLabel(ci.selectedVariant, ci.item.sku)})`
                    : '';
                  return (
                    <div key={ci.id} className="flex justify-between items-center pt-3 gap-2">
                      <div className="flex-grow">
                        <p className={`text-xs leading-snug ${isDarkTheme ? 'text-white font-black' : 'text-slate-900 font-extrabold'}`}>
                          {displayName}{variantSuffix}
                        </p>
                        <p className={`font-bold text-2xs mt-0.5 ${activeTheme.primaryText}`}>${activePrice.toFixed(2)} each</p>
                      </div>

                      {/* Quantity actions */}
                      <div className="flex items-center space-x-2 shrink-0">
                        <button
                          onClick={() => updateQty(ci.id, -1)}
                          className={`w-5.5 h-5.5 rounded-[5px] flex items-center justify-center transition-colors text-2xs ${isDarkTheme
                              ? 'bg-slate-800 hover:bg-slate-700 text-slate-350'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                            }`}
                        >
                          <FiMinus className="w-3 h-3" />
                        </button>
                        <span className={`text-xs font-black w-4 text-center ${isDarkTheme ? 'text-white' : 'text-slate-800'}`}>{ci.qty}</span>
                        <button
                          onClick={() => updateQty(ci.id, 1)}
                          className={`w-5.5 h-5.5 rounded-[5px] flex items-center justify-center transition-colors text-2xs ${isDarkTheme
                              ? 'bg-slate-800 hover:bg-slate-700 text-slate-350'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                            }`}
                        >
                          <FiPlus className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => removeFromCart(ci.id, `${displayName}${variantSuffix}`)}
                          className="text-slate-400 hover:text-rose-500 p-1 transition-colors"
                        >
                          <FiTrash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Pink discount free delivery advertisement (When cart is empty) */
            <div className="py-6 flex flex-col items-center justify-center text-center space-y-4">
              <div className={`w-16 h-16 rounded-[5px] flex items-center justify-center shadow-3xs ${isDarkTheme ? 'bg-rose-950/30 border border-rose-900/30 text-rose-400' : 'bg-rose-50/50 text-rose-500'
                }`}>
                {/* Ticket emoji with high contrast pink/rose details */}
                <span className="text-3xl">🎟️</span>
              </div>
              <div>
                <h4 className={`font-extrabold text-sm ${isDarkTheme ? 'text-white' : 'text-slate-800'}`}>
                  Free delivery on your first order
                </h4>
                <p className="text-slate-400 text-2xs font-semibold leading-relaxed mt-1">
                  Add delicious items to your cart to unlock free delivery coupons!
                </p>
              </div>
            </div>
          )}

          {/* Subtotal Calculations */}
          <div className={`pt-4 border-t space-y-2 text-xs font-semibold ${isDarkTheme ? 'border-slate-800/60' : 'border-slate-100'}`}>
            {subtotal > 0 && (
              <>
                <div className="flex justify-between text-slate-400">
                  <span>Subtotal:</span>
                  <span className={`font-bold ${isDarkTheme ? 'text-slate-200' : 'text-slate-800'}`}>${subtotal.toFixed(2)}</span>
                </div>
                {orderMethod === 'delivery' && (
                  <div className="flex justify-between text-slate-400">
                    <span>Delivery Fee:</span>
                    <span className={`font-bold ${isDarkTheme ? 'text-slate-200' : 'text-slate-800'}`}>
                      {deliveryFee === 0 ? <span className="text-emerald-500 font-extrabold">FREE</span> : `$${deliveryFee.toFixed(2)}`}
                    </span>
                  </div>
                )}
              </>
            )}

            <div className={`flex justify-between items-center text-sm font-black pt-1 ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>
              <span>Total <span className="text-[10px] font-semibold text-slate-400">(incl. fees & tax)</span></span>
              <span className={`text-base font-black ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>${total.toFixed(2)}</span>
            </div>
          </div>

          {/* Review Button */}
          <button
            disabled={cart.length === 0}
            onClick={() => {
              toast.success('Proceeding to Checkout! Preparing payment and address gateways...');
            }}
            className={`w-full py-3.5 rounded-[5px] font-black text-xs text-center border-none transition-all active:scale-98 cursor-pointer ${cart.length > 0
                ? `${activeTheme.primaryBg} ${activeTheme.primaryHover} text-white shadow-md ${activeTheme.shadowClass}`
                : `${isDarkTheme ? 'bg-slate-800 text-slate-600' : 'bg-slate-100 text-slate-400'} cursor-not-allowed`
              }`}
          >
            Review payment and address
          </button>

        </div>

      </div>

    </section>
  );
};

