import React from 'react';
import {
    FiArrowRight,
    FiClock,
    FiTruck,
    FiShoppingBag,
} from 'react-icons/fi';

import type { SettingResponse } from '@/api/setting';
import { themes } from '@/pages/owner_manage/templete_website/themes';

interface HeroPageProps {
    token: string | null;
    onNavigateLogin: () => void;
    onNavigate: (to: string) => void;
    settings?: SettingResponse['settings'] | null;
}

export const HeroPage: React.FC<HeroPageProps> = ({
    token,
    onNavigateLogin,
    onNavigate,
    settings,
}) => {
    const activeTheme = themes[settings?.website_theme || 'default'] || themes.default;
    const isDarkTheme = (settings?.website_theme || '').startsWith('minimal_dark') || settings?.website_theme === 'glass_gradient' || settings?.website_theme === 'electronic';

    return (
        <section
            id="home"
            className={`relative py-20 lg:py-28 overflow-hidden transition-all duration-300 border-b ${activeTheme.bgClass} ${activeTheme.borderClass} animate-fade-in`}
        >
            {/* Dot-grid pattern overlay */}
            <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#ff6b35_1px,transparent_1px)] [background-size:24px_24px]" />

            {/* Ambient glows */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-slate-400/10 rounded-full blur-[120px] pointer-events-none -z-0" />
            <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-slate-300/10 rounded-full blur-[100px] pointer-events-none -z-0" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center">

                    {/* ── Left: Copy ──────────────────────────────── */}
                    <div className="lg:col-span-6 text-left space-y-6 animate-slide-up">

                        {/* Badge */}
                        <span className={`inline-flex items-center space-x-1.5 px-4 py-1.5 rounded-[5px] text-xs font-black uppercase tracking-wider ${activeTheme.badgeBg} ${activeTheme.badgeText}`}>
                            <FiClock className="animate-spin" style={{ animationDuration: '6s' }} />
                            <span>30 Minutes Flash Delivery</span>
                        </span>

                        {/* Headline */}
                        <h1 className={`text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>
                            Super Delicious Meals <br />
                            Delivered{' '}
                            <span className={`${activeTheme.primaryText} underline decoration-wavy decoration-current`}>
                                Fast &amp; Fresh
                            </span>
                        </h1>

                        {/* Sub-copy */}
                        <p className={`text-sm sm:text-base lg:text-lg leading-relaxed max-w-xl ${isDarkTheme ? 'text-slate-450 font-normal' : 'text-slate-500 font-medium'}`}>
                            Satisfy your cravings with premium burgers, wood-fired pizzas, crisp healthy salads,
                            and gourmet pastries prepared daily by highly skilled culinary artisans.
                        </p>

                        {/* CTA Buttons */}
                        <div className="flex flex-col sm:flex-row gap-4 pt-2">
                            {!token ? (
                                <button
                                    onClick={onNavigateLogin}
                                    className={`w-full sm:w-auto px-8 py-4 ${activeTheme.primaryBg} ${activeTheme.primaryHover} text-white font-extrabold rounded-[5px] transition-all shadow-lg ${activeTheme.shadowClass} flex items-center justify-center space-x-2 text-base border border-transparent cursor-pointer hover:scale-[1.02] active:scale-[0.98]`}
                                >
                                    <span>Get Started &amp; Save 20%</span>
                                    <FiArrowRight className="w-5 h-5" />
                                </button>
                            ) : (
                                <a
                                    href="/menu"
                                    onClick={(e) => { e.preventDefault(); onNavigate('/menu'); }}
                                    className={`w-full sm:w-auto px-8 py-4 ${activeTheme.primaryBg} ${activeTheme.primaryHover} text-white font-extrabold rounded-[5px] transition-all shadow-lg ${activeTheme.shadowClass} flex items-center justify-center space-x-2 text-base border border-transparent cursor-pointer hover:scale-[1.02] active:scale-[0.98]`}
                                >
                                    <span>Explore Active Menu</span>
                                    <FiShoppingBag className="w-5 h-5" />
                                </a>
                            )}

                            <a
                                href="#services"
                                className={`w-full sm:w-auto px-8 py-4 ${activeTheme.cardBg} hover:bg-slate-50/5 border ${activeTheme.borderClass} ${isDarkTheme ? 'text-slate-200 hover:text-white' : 'text-slate-700 hover:text-slate-900'} font-extrabold rounded-[5px] transition-all flex items-center justify-center space-x-2 text-base cursor-pointer shadow-sm active:scale-[0.98]`}
                            >
                                <span>Our Services</span>
                            </a>
                        </div>

                        {/* Stats row */}
                        <div className={`grid grid-cols-3 gap-6 pt-6 border-t ${isDarkTheme ? 'border-slate-800' : 'border-slate-100'} max-w-md`}>
                            <div>
                                <span className={`text-2xl sm:text-3xl font-black block ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>50k+</span>
                                <span className="text-xs text-slate-400 font-bold block">Happy Clients</span>
                            </div>
                            <div>
                                <span className={`text-2xl sm:text-3xl font-black block ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>120+</span>
                                <span className="text-xs text-slate-400 font-bold block">Gourmet Chefs</span>
                            </div>
                            <div>
                                <span className={`text-2xl sm:text-3xl font-black block ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>4.9★</span>
                                <span className="text-xs text-slate-400 font-bold block">Customer Rating</span>
                            </div>
                        </div>
                    </div>

                    {/* ── Right: Visual ────────────────────────────── */}
                    <div className="lg:col-span-6 flex justify-center relative">
                        <div className="absolute w-[300px] h-[300px] sm:w-[450px] sm:h-[450px] bg-slate-400/10 rounded-full blur-3xl -z-10 animate-pulse-slow" />

                        <div className={`relative w-full max-w-[480px] p-4 rounded-[5px] transition-all duration-500 shadow-lg border transform rotate-1 hover:rotate-0 ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.glassClass || ''}`}>
                            <img
                                src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=800&q=80"
                                alt="Delicious Premium Food Selection"
                                className="rounded-[5px] w-full h-[320px] object-cover shadow-sm"
                            />

                            {/* Floating card – Trending */}
                            <div
                                className={`absolute top-8 left-[-20px] p-3 rounded-[5px] shadow-md border flex items-center space-x-3 animate-bounce ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.glassClass || ''}`}
                                style={{ animationDuration: '4s' }}
                            >
                                <span className="text-2xl">🔥</span>
                                <div>
                                    <span className={`text-xs font-black block ${isDarkTheme ? 'text-slate-200' : 'text-slate-800'}`}>Trending Pizza</span>
                                    <span className="text-[10px] text-slate-400 font-bold block">1.2k orders today</span>
                                </div>
                            </div>

                            {/* Floating card – Delivery */}
                            <div
                                className={`absolute bottom-8 right-[-20px] p-3.5 rounded-[5px] shadow-md border flex items-center space-x-3 animate-bounce ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.glassClass || ''}`}
                                style={{ animationDuration: '5s', animationDelay: '1s' }}
                            >
                                <div className={`p-2 rounded-[5px] border ${activeTheme.badgeBg} ${activeTheme.badgeText}`}>
                                    <FiTruck className="w-5 h-5" />
                                </div>
                                <div>
                                    <span className={`text-xs font-black block ${isDarkTheme ? 'text-slate-200' : 'text-slate-800'}`}>Fast Delivery</span>
                                    <span className="text-[10px] text-slate-400 font-bold block">On Time Guarantee</span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
    );
};
