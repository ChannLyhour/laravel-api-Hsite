import React, { useEffect, useState } from 'react';
import { authService } from '@/api/auth';
import type { UserResponse } from '@/api/auth';
import { ApiError } from '@/api/client';
import { NavbarPage } from './NavbarPage';
import { HeroPage } from './HeroPage';
import { MenuItemPage } from './MenuItemPage';
import { FooterPage } from './FooterPage';
import { CafeShopPage } from '../templetes/cafeShop_website/CafeShopPage';
import { ElectronicPage } from '../templetes/Electronic_website/ElectronicPage';
import { FashionPage } from '../templetes/fashion_website/FashionPage';
import type { SettingResponse } from '@/api/setting';
import type { StoreRow } from '@/api/owner/stores';
import { themes } from '@/pages/owner_manage/templete_website/themes';
import { PhoneAppView } from '../mobile/phone/PhoneAppView';
import { TabletAppView } from '../mobile/tablet/TabletAppView';
import { storeBrandingService } from '@/api/created_by/getFaviconById';
import {
  FiAward,
  FiClock,
  FiShield,
  FiHeart,
  FiStar,
} from 'react-icons/fi';

interface HomePageProps {
  token: string | null;
  settings: SettingResponse['settings'] | null;
  /** Authoritative store row from the stores table (has store_name, logo_url, etc.) */
  storeInfo?: StoreRow | null;
  currentPath: string;
  onNavigate: (to: string) => void;
  onNavigateLogin: () => void;
  onLogout: () => void;
  ownerUserId?: number | string;
  onOwnerChange: (id: number) => void;
  /** Store name from the ?store= URL param for owner-specific storefronts */
  storeName?: string;
}

export const HomePage: React.FC<HomePageProps> = ({
  token,
  settings,
  storeInfo,
  currentPath,
  onNavigate,
  onNavigateLogin,
  onLogout,
  ownerUserId,
  onOwnerChange,
  storeName = '',
}) => {
  const [profile, setProfile] = useState<UserResponse | null>(null);
  const [locale, setLocale] = useState<'en' | 'km'>('en');

  // Dynamically update favicon for this specific store
  useEffect(() => {
    if (ownerUserId) {
      storeBrandingService.getFaviconByOwnerId(ownerUserId)
        .then(url => {
          if (url) storeBrandingService.applyFavicon(`${url}?v=${Date.now()}`);
        })
        .catch(err => console.warn('HomePage: Failed to load favicon', err));
    }
  }, [ownerUserId]);

  // Load profile when authenticated
  useEffect(() => {
    let active = true;

    if (!token) {
      if (active) setProfile(null);
      return;
    }

    const fetchProfile = async () => {
      try {
        const data = await authService.getCurrentUser();
        if (active) setProfile(data);
      } catch (err) {
        if (err instanceof ApiError) {
          if (err.status === 401 && active) {
            onLogout();
          }
        }
      }
    };

    fetchProfile();
    return () => { active = false; };
  }, [token, onLogout]);

  const [isMobileScreen, setIsMobileScreen] = useState(false);
  const [isTabletScreen, setIsTabletScreen] = useState(false);
  const [forceDesktop, setForceDesktop] = useState(() => {
    return sessionStorage.getItem('force_desktop_view') === 'true';
  });

  const handleToggleForceDesktop = (force: boolean) => {
    setForceDesktop(force);
    if (force) {
      sessionStorage.setItem('force_desktop_view', 'true');
    } else {
      sessionStorage.removeItem('force_desktop_view');
    }
  };

  useEffect(() => {
    const handleResize = () => {
      setIsMobileScreen(window.innerWidth < 768);
      setIsTabletScreen(window.innerWidth >= 768 && window.innerWidth < 1024);
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isMenuView = currentPath.endsWith('/menu');

  const activeTheme = themes[settings?.website_theme || 'default'] || themes.default;

  // Intercept and render dynamic smart phone native e-commerce app layout
  if (isMobileScreen && !forceDesktop) {
    return (
      <PhoneAppView
        ownerUserId={ownerUserId}
        storeName={storeName || settings?.store_name}
        settings={settings}
        locale={locale}
        token={token}
        profile={profile}
        onToggleDesktop={() => handleToggleForceDesktop(true)}
        onLogout={onLogout}
      />
    );
  }

  // Intercept and render dynamic tablet split-screen e-commerce ordering dashboard
  if (isTabletScreen && !forceDesktop) {
    return (
      <TabletAppView
        ownerUserId={ownerUserId}
        storeName={storeName || settings?.store_name}
        settings={settings}
        locale={locale}
        token={token}
        profile={profile}
        onToggleDesktop={() => handleToggleForceDesktop(true)}
      />
    );
  }

  // Intercept and render dynamic niche template builder storefronts
  if (settings?.website_theme === 'cafe_shop') {
    return (
      <CafeShopPage
        ownerUserId={ownerUserId}
        profile={profile}
        onNavigate={onNavigate}
        storeName={storeName || settings?.store_name}
        locale={locale}
        settings={settings}
      />
    );
  }
  if (settings?.website_theme === 'electronic') {
    return (
      <ElectronicPage
        ownerUserId={ownerUserId}
        profile={profile}
        onNavigate={onNavigate}
        storeName={storeName || settings?.store_name}
        locale={locale}
        settings={settings}
      />
    );
  }
  if (settings?.website_theme === 'fashion') {
    return (
      <FashionPage
        ownerUserId={ownerUserId}
        profile={profile}
        onNavigate={onNavigate}
        storeName={storeInfo?.store_name || storeName || settings?.store_name}
        locale={locale}
        stores={(storeInfo ?? settings) as any}
        currentPath={currentPath}
      />
    );
  }

  return (
    <div className={`min-h-screen flex flex-col transition-all duration-300 ${activeTheme.bgClass} animate-fade-in`}>
      {/* Dynamic Header/Navbar */}
      <NavbarPage
        token={token}
        profile={profile}
        onNavigateLogin={onNavigateLogin}
        onLogout={onLogout}
        onNavigate={onNavigate}
        currentPath={currentPath}
        stores={settings}
        onOwnerChange={onOwnerChange}
        storeName={storeName}
        ownerUserId={ownerUserId}
        locale={locale}
        setLocale={setLocale}
      />


      <main className="flex-grow">
        {isMenuView ? (
          /* Dedicated Standalone Menu Page View (Not using section) */
          <div className="animate-fade-in">
            <MenuItemPage
              ownerUserId={ownerUserId}
              profile={profile}
              onNavigate={onNavigate}
              storeName={storeName || settings?.store_name || 'Food'}
              locale={locale}
              settings={settings}
            />
          </div>
        ) : (
          /* Main Homepage Sections */
          <>
            {/* ========================================================================= */}
            {/* ── 1. HERO SECTION (Modular HeroPage Component) ────────────────────── */}
            {/* ========================================================================= */}
            <HeroPage
              token={token}
              onNavigateLogin={onNavigateLogin}
              onNavigate={onNavigate}
              settings={settings}
            />

            {/* ========================================================================= */}
            {/* ── 2. FEATURED PRODUCTS SHOWCASE SECTION ───────────────────────────────── */}
            {/* ========================================================================= */}
            <div className={`border-t transition-all duration-300 ${activeTheme.cardBg} ${activeTheme.borderClass}`}>
              <MenuItemPage
                ownerUserId={ownerUserId}
                profile={profile}
                onNavigate={onNavigate}
                storeName={storeName || settings?.store_name || 'Food'}
                locale={locale}
                settings={settings}
              />
            </div>

            {/* ========================================================================= */}
            {/* ── 3. SERVICE SECTION ──────────────────────────────────────────────────── */}
            {/* ========================================================================= */}
            {
              (() => {
                const isDarkTheme = (settings?.website_theme || '').startsWith('minimal_dark') || settings?.website_theme === 'glass_gradient' || settings?.website_theme === 'electronic';
                return (
                  <section
                    id="services"
                    className={`py-20 border-y transition-all duration-300 ${isDarkTheme
                        ? 'bg-slate-950/40 border-slate-800/50'
                        : 'bg-slate-100/50 border-slate-100'
                      }`}
                  >
                    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

                      {/* Section Header */}
                      <div className="text-center space-y-4 mb-16 animate-slide-up">
                        <span className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-[5px] text-xs font-black uppercase tracking-wider ${activeTheme.badgeBg} ${activeTheme.badgeText}`}>
                          <FiAward />
                          <span>Our Core Advantages</span>
                        </span>
                        <h2 className={`text-3xl sm:text-4xl tracking-tight ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>
                          Why foodies order from {storeName || settings?.store_name || 'Food'}
                        </h2>
                        <p className={`text-sm sm:text-base max-w-xl mx-auto ${isDarkTheme ? 'text-slate-400 font-normal' : 'text-slate-500 font-medium'}`}>
                          We combine traditional culinary standards with modern delivery logistics to build an exceptional food service.
                        </p>
                      </div>

                      {/* Service Grid */}
                      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">

                        {/* Service 1 */}
                        <div className={`p-6 sm:p-8 rounded-[5px] text-center space-y-4 hover:scale-[1.01] transition-transform ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.shadowClass}`}>
                          <div className={`w-14 h-14 rounded-[5px] flex items-center justify-center mx-auto ${activeTheme.badgeBg} ${activeTheme.primaryText}`}>
                            <FiClock className="w-7 h-7" />
                          </div>
                          <h3 className={`text-lg ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>Fast 30min Delivery</h3>
                          <p className={`text-xs sm:text-sm leading-relaxed font-semibold ${isDarkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                            We guarantee delivery to your address in 30 minutes, or you receive 50% discount on your meals.
                          </p>
                        </div>

                        {/* Service 2 */}
                        <div className={`p-6 sm:p-8 rounded-[5px] text-center space-y-4 hover:scale-[1.01] transition-transform ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.shadowClass}`}>
                          <div className={`w-14 h-14 rounded-[5px] flex items-center justify-center mx-auto ${activeTheme.badgeBg} ${activeTheme.primaryText}`}>
                            <FiStar className="w-7 h-7" />
                          </div>
                          <h3 className={`text-lg ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>Premium Grade Chefs</h3>
                          <p className={`text-xs sm:text-sm leading-relaxed font-semibold ${isDarkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                            Our meals are prepared by award-winning chefs who strictly hold five-star kitchen culinary standards.
                          </p>
                        </div>

                        {/* Service 3 */}
                        <div className={`p-6 sm:p-8 rounded-[5px] text-center space-y-4 hover:scale-[1.01] transition-transform ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.shadowClass}`}>
                          <div className={`w-14 h-14 rounded-[5px] flex items-center justify-center mx-auto ${activeTheme.badgeBg} ${activeTheme.primaryText}`}>
                            <FiHeart className="w-7 h-7" />
                          </div>
                          <h3 className={`text-lg ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>Always Fresh & Organic</h3>
                          <p className={`text-xs sm:text-sm leading-relaxed font-semibold ${isDarkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                            We prepare meals strictly from local fresh farm organic vegetables and non-GMO grains every day.
                          </p>
                        </div>

                        {/* Service 4 */}
                        <div className={`p-6 sm:p-8 rounded-[5px] text-center space-y-4 hover:scale-[1.01] transition-transform ${activeTheme.cardBg} ${activeTheme.borderClass} ${activeTheme.shadowClass}`}>
                          <div className={`w-14 h-14 rounded-[5px] flex items-center justify-center mx-auto ${activeTheme.badgeBg} ${activeTheme.primaryText}`}>
                            <FiShield className="w-7 h-7" />
                          </div>
                          <h3 className={`text-lg ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-900'}`}>Secure & Clean Packs</h3>
                          <p className={`text-xs sm:text-sm leading-relaxed font-semibold ${isDarkTheme ? 'text-slate-400' : 'text-slate-500'}`}>
                            Food is packed strictly in sealed, heat-insulated, double-layered packages to keep meals perfectly hot.
                          </p>
                        </div>

                      </div>

                    </div>
                  </section>
                );
              })()
            }
          </>
        )}
      </main>
      <FooterPage token={token} stores={settings as any} onNavigate={onNavigate} storeName={storeName} ownerUserId={ownerUserId} />

      {/* Floating segment button allowing user to switch back to premium mobile app preview viewports */}
      {forceDesktop && (
        <div className="fixed bottom-6 right-6 z-50 animate-fade-in select-none">
          <button
            onClick={() => handleToggleForceDesktop(false)}
            className={`px-5 py-3.5 rounded-full shadow-2xl font-black text-xs text-white cursor-pointer transition-all active:scale-95 flex items-center space-x-2 border border-white/10 hover:opacity-95 ${activeTheme.primaryBg} ${activeTheme.shadowClass}`}
          >
            <span>📱 Switch to Mobile App Preview</span>
          </button>
        </div>
      )}

    </div>
  );
};

