import React, { useState, useEffect } from 'react';
import type { UserResponse } from '@/api/auth';
import { FiUser, FiShare2, FiCopy, FiX } from 'react-icons/fi';
import { themes } from '@/pages/owner_manage/templete_website/themes';
import { shareService } from '@/api/owner/share';
import { Store_setting } from '@/api/owner/stores';
import { toast } from 'react-hot-toast';

interface NavbarPageProps {
    token: string | null;
    profile: UserResponse | null;
    onNavigateLogin: () => void;
    onLogout: () => void;
    onNavigate: (to: string) => void;
    currentPath: string;
    stores: any;
    onOwnerChange: (id: number) => void;
    storeName?: string;
    ownerUserId?: number | string;
    locale: 'en' | 'km';
    setLocale: (l: 'en' | 'km') => void;
}

export const NavbarPage: React.FC<NavbarPageProps> = ({
    token,
    profile,
    onNavigateLogin,
    onLogout,
    onNavigate,
    currentPath,
    stores,
    onOwnerChange,
    storeName = '',
    ownerUserId,
    locale,
    setLocale,
}) => {
    // Local state to track dynamic settings for real-time updates
    const [dynamicStores, setDynamicStores] = useState<any>(() => stores || Store_setting());

    useEffect(() => {
        const handleUpdate = () => {
            const updated = Store_setting();
            if (updated) setDynamicStores(updated);
        };
        window.addEventListener('settings_updated', handleUpdate);
        return () => window.removeEventListener('settings_updated', handleUpdate);
    }, []);

    // Sync if props change
    useEffect(() => {
        let active = true;
        if (stores && active) setDynamicStores(stores);
        return () => { active = false; };
    }, [stores]);

    const settings = dynamicStores || stores;

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const [isShareModalOpen, setIsShareModalOpen] = useState(false);
    const [generatedShareUrl, setGeneratedShareUrl] = useState('');
    const [isSharing, setIsSharing] = useState(false);

    const activeTheme = themes[settings?.website_theme || 'default'] || themes.default;
    const isDarkTheme = (settings?.website_theme || '').startsWith('minimal_dark') || settings?.website_theme === 'glass_gradient' || settings?.website_theme === 'electronic';

    const handleShareClick = async () => {
        setIsSharing(true);
        try {
            const activeSettings = settings || Store_setting() || {};

            const payload = {
                stores: activeSettings,
                ownerUserId: ownerUserId
            };

            const response = await shareService.saveShare(payload);
            if (response && response.success && response.id) {
                const shareUrl = `${window.location.origin}/share/${response.id}`;
                setGeneratedShareUrl(shareUrl);
                setIsShareModalOpen(true);
                toast.success('Share link generated!');
            } else {
                toast.error('Failed to generate share link.');
            }
        } catch (err) {
            console.error('Error generating share link:', err);
            toast.error('Error generating share link.');
        } finally {
            setIsSharing(false);
        }
    };

    const buildStoreLink = (path: string) => {
        if (!storeName) return path;
        const storeSlug = storeName.replace(/\s+/g, '_');

        const cleanPath = path.split('?')[0].split('#')[0];
        const hash = path.includes('#') ? `#${path.split('#')[1]}` : '';

        if (cleanPath === '/' || cleanPath === '/home' || cleanPath === '') {
            return `/${storeSlug}${hash}`;
        }
        if (cleanPath === '/menu' || cleanPath === '/owner/menu') {
            return `/${storeSlug}/menu${hash}`;
        }
        return `/${storeSlug}${cleanPath}${hash}`;
    };

    const isActive = (path: string) => {
        const hash = window.location.hash;
        if (path === '/') {
            return (currentPath === '/' || currentPath === '/home') && !hash;
        }
        if (path === '/menu' || path === '/owner/menu') {
            return currentPath === '/menu' || currentPath === '/owner/menu';
        }
        if (path.includes('#')) {
            const targetHash = path.split('#')[1];
            return hash === `#${targetHash}`;
        }
        return false;
    };

    const getLinkClass = (path: string) => {
        const active = isActive(path);
        return `font-bold text-sm transition-all duration-200 cursor-pointer ${active
                ? `${activeTheme.primaryText} font-black border-b-2 border-current pb-1`
                : `${isDarkTheme ? 'text-slate-400 hover:text-white' : 'text-slate-600 hover:' + activeTheme.primaryText}`
            }`;
    };

    return (
        <header className={`sticky top-0 z-50 transition-all duration-300 ${activeTheme.navbarBg}`}>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">

                {/* Brand Logo */}
                <a
                    href={buildStoreLink('/')}
                    onClick={(e) => { e.preventDefault(); onNavigate(buildStoreLink('/')); }}
                    className="flex items-center space-x-3 cursor-pointer"
                >
                    {settings?.logo_url ? (
                        <img
                            src={settings.logo_url}
                            alt={settings.store_name || storeName || 'BiteFlow Store'}
                            className="h-10 w-auto object-contain rounded-[5px] shadow-sm border border-slate-100"
                        />
                    ) : (
                        <div className={`p-2 rounded-[5px] text-white shadow-md ${activeTheme.primaryBg} ${activeTheme.shadowClass}`}>
                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707-.707m0-12.728l.707.707m12.728 12.728l.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z" />
                            </svg>
                        </div>
                    )}
                    <span className={`text-xl tracking-tight ${activeTheme.headingFont} ${isDarkTheme ? 'text-white' : 'text-slate-800'}`}>
                        {settings?.store_name || storeName || 'BiteFlow Store'}
                    </span>
                </a>

                {/* Navigation Links */}
                <nav className="hidden md:flex space-x-8 items-center">
                    <a
                        href={buildStoreLink('/')}
                        onClick={(e) => { e.preventDefault(); onNavigate(buildStoreLink('/')); }}
                        className={getLinkClass('/')}
                    >
                        Home
                    </a>
                    <a
                        href={buildStoreLink('/owner/menu')}
                        onClick={(e) => { e.preventDefault(); onNavigate(buildStoreLink('/owner/menu')); }}
                        className={getLinkClass('/owner/menu')}
                    >
                        Our Menu
                    </a>
                    <a
                        href={buildStoreLink('/#services')}
                        onClick={(e) => { e.preventDefault(); onNavigate(buildStoreLink('/#services')); }}
                        className={getLinkClass('/#services')}
                    >
                        Why Us
                    </a>
                    {profile && (
                        <a
                            href={buildStoreLink('/#orders')}
                            onClick={(e) => { e.preventDefault(); onNavigate(buildStoreLink('/#orders')); }}
                            className={getLinkClass('/#orders')}
                        >
                            Workspace
                        </a>
                    )}

                </nav>

                {/* Auth Action Buttons */}
                <div className="flex items-center space-x-4">
                    {/* Share Layout Button */}
                    <button
                        onClick={handleShareClick}
                        disabled={isSharing}
                        title="Share your custom storefront design with others"
                        className={`flex items-center space-x-1.5 px-3 py-1.5 bg-slate-50 dark:bg-slate-900 border ${activeTheme.borderClass} text-slate-500 hover:${activeTheme.primaryText} font-bold text-xs rounded-[5px] transition-all cursor-pointer disabled:opacity-50 select-none`}
                    >
                        {isSharing ? (
                            <div className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                        ) : (
                            <FiShare2 className="w-3.5 h-3.5" />
                        )}
                        <span className="hidden sm:inline">{isSharing ? 'Sharing...' : 'Share Design'}</span>
                    </button>

                    {/* Language Switcher */}
                    <div className={`flex items-center p-0.5 rounded-[5px] shrink-0 font-kuntomruy border ${activeTheme.borderClass} ${activeTheme.cardBg}`}>
                        <button
                            type="button"
                            onClick={() => setLocale('en')}
                            className={`px-2 py-1 rounded-[4px] text-[10px] font-black tracking-wider uppercase transition-all flex items-center space-x-1 cursor-pointer border-none ${locale === 'en'
                                    ? 'bg-white text-slate-800 shadow-2xs font-extrabold font-black'
                                    : 'text-slate-400 hover:text-slate-600 bg-transparent'
                                }`}
                        >
                            <span>🇬🇧</span>
                            <span className="hidden sm:inline">EN</span>
                        </button>
                        <button
                            type="button"
                            onClick={() => setLocale('km')}
                            className={`px-2 py-1 rounded-[4px] text-[10px] font-black tracking-wider uppercase transition-all flex items-center space-x-1 cursor-pointer border-none ${locale === 'km'
                                    ? 'bg-white text-slate-800 shadow-2xs font-extrabold font-black'
                                    : 'text-slate-400 hover:text-slate-600 bg-transparent'
                                }`}
                        >
                            <span>🇰🇭</span>
                            <span className="hidden sm:inline">KH</span>
                        </button>
                    </div>

                    {token ? (
                        <div className="relative">
                            {/* User Avatar + Details trigger for dropdown */}
                            <div
                                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                                className="flex items-center space-x-3 cursor-pointer hover:bg-slate-50 p-1.5 rounded-[5px] transition-all duration-200 border border-slate-100 bg-white"
                            >
                                <div className="text-right hidden sm:block">
                                    <p className="text-sm font-black text-slate-800 leading-tight">
                                        {profile?.user?.name || 'Testing Account'}
                                    </p>
                                    <p className="text-[10px] font-bold text-slate-400 capitalize">
                                        {profile?.user?.role || 'Owner'} Account
                                    </p>
                                </div>
                                <div className={`w-10 h-10 rounded-[5px] border ${activeTheme.borderClass} ${activeTheme.badgeBg} flex items-center justify-center font-black ${activeTheme.badgeText} shadow-sm text-sm`}>
                                    {profile?.user?.name ? profile.user.name.charAt(0).toUpperCase() : 'U'}
                                </div>
                                <svg className={`w-3.5 h-3.5 text-slate-400 transition-transform duration-200 ${isDropdownOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                                </svg>
                            </div>

                            {/* Dropdown Menu Box */}
                            {isDropdownOpen && (
                                <>
                                    {/* Backdrop overlay */}
                                    <div className="fixed inset-0 z-40 cursor-default" onClick={() => setIsDropdownOpen(false)}></div>

                                    <div className="absolute right-0 mt-3 w-64 bg-white rounded-[5px] border border-slate-100 shadow-xl py-2 z-50 animate-slide-up">

                                        {/* Dropdown Header */}
                                        <div className="px-4 py-2 border-b border-slate-100 mb-1.5">
                                            <p className="text-[9px] text-slate-400 font-extrabold uppercase tracking-widest">Active Operator</p>
                                            <p className="text-xs font-black text-slate-800 truncate mt-0.5">{profile?.user?.name || 'Testing Account'}</p>
                                            <p className="text-[10px] text-slate-400 font-bold capitalize mt-0.5">{profile?.user?.role || 'owner'} panel</p>
                                        </div>

                                        {/* Dropdown Links */}
                                        <div className="space-y-0.5">
                                            {profile?.user && (
                                                <button
                                                    onClick={() => {
                                                        setIsDropdownOpen(false);
                                                        onOwnerChange(profile.user.id);
                                                        onNavigate('/menu');
                                                    }}
                                                    className={`w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:${activeTheme.primaryText} font-bold text-xs transition-colors flex items-center space-x-2.5 border-none cursor-pointer`}
                                                >
                                                    <svg className="w-4 h-4 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                                                    </svg>
                                                    <span>My Restaurant Menu</span>
                                                </button>
                                            )}

                                            {profile?.user && (profile.user.role === 'owner' || profile.user.role === 'admin' || profile.user.role === 'staff') && (
                                                <button
                                                    onClick={() => {
                                                        setIsDropdownOpen(false);
                                                        onNavigate('/owner');
                                                    }}
                                                    className={`w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:${activeTheme.primaryText} font-bold text-xs transition-colors flex items-center space-x-2.5 border-none cursor-pointer`}
                                                >
                                                    <svg className="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                                    </svg>
                                                    <span>Manage Restaurant</span>
                                                </button>
                                            )}

                                            <button
                                                onClick={() => {
                                                    setIsDropdownOpen(false);
                                                    window.location.href = '/';
                                                }}
                                                className={`w-full text-left px-4 py-2.5 hover:bg-slate-50 text-slate-700 hover:${activeTheme.primaryText} font-bold text-xs transition-colors flex items-center space-x-2.5 border-none cursor-pointer`}
                                            >
                                                <svg className="w-4 h-4 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                                                </svg>
                                                <span>BiteFlow Platform</span>
                                            </button>
                                        </div>

                                        <div className="border-t border-slate-100 my-1.5" />

                                        {/* Logout Option */}
                                        <button
                                            onClick={() => {
                                                setIsDropdownOpen(false);
                                                onLogout();
                                            }}
                                            className="w-full text-left px-4 py-2.5 hover:bg-rose-50 text-rose-600 font-extrabold text-xs transition-colors flex items-center space-x-2.5 border-none cursor-pointer"
                                        >
                                            <svg className="w-4 h-4 text-rose-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                            </svg>
                                            <span>Logout / Sign Out</span>
                                        </button>
                                    </div>
                                </>
                            )}
                        </div>
                    ) : (
                        <>
                            {/* BiteFlow Platform Link Button */}
                            <button
                                onClick={() => { window.location.href = '/'; }}
                                title="Return to the main BiteFlow Platform"
                                className={`hidden sm:flex items-center space-x-1.5 px-3.5 py-2 bg-slate-50 hover:bg-slate-100 border ${activeTheme.borderClass} text-slate-500 hover:${activeTheme.primaryText} font-extrabold text-xs rounded-[5px] transition-all cursor-pointer`}
                            >
                                <svg className={`w-3.5 h-3.5 ${activeTheme.primaryText}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                                </svg>
                                <span>BiteFlow Platform</span>
                            </button>

                            <button
                                onClick={onNavigateLogin}
                                className={`px-5 py-2.5 ${activeTheme.primaryBg} ${activeTheme.primaryHover} text-white font-extrabold text-xs sm:text-sm rounded-[5px] transition-all shadow-md ${activeTheme.shadowClass} flex items-center space-x-2 cursor-pointer border border-transparent`}
                            >
                                <FiUser className="w-4.5 h-4.5 sm:w-5 sm:h-5 text-white" />
                                <span>Login</span>
                            </button>
                        </>
                    )}
                </div>

            </div>

            {isShareModalOpen && (
                <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
                    {/* Backdrop */}
                    <div
                        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity cursor-default"
                        onClick={() => setIsShareModalOpen(false)}
                    />

                    {/* Modal content */}
                    <div className="relative bg-white dark:bg-slate-900 rounded-lg max-w-md w-full p-6 shadow-2xl border border-slate-100 dark:border-slate-800 transform transition-all scale-100 animate-fade-in font-kuntomruy">
                        {/* Close button */}
                        <button
                            onClick={() => setIsShareModalOpen(false)}
                            className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 border-none"
                        >
                            <FiX className="w-4 h-4" />
                        </button>

                        <div className="text-center space-y-4">
                            {/* Icon */}
                            <div className="w-10 h-10 rounded-full mx-auto flex items-center justify-center bg-orange-100 dark:bg-orange-950/50 text-orange-500">
                                <FiShare2 className="w-5 h-5" />
                            </div>

                            <div className="space-y-1">
                                <h3 className="text-sm font-black text-slate-800 dark:text-white">Share Your Store Design</h3>
                                <p className="text-[11px] text-slate-400 font-medium leading-relaxed">
                                    Copy the link below to share this exact layout, colors, and configuration with anyone!
                                </p>
                            </div>

                            {/* Link input + Copy button */}
                            <div className="flex items-center space-x-2 mt-4">
                                <input
                                    type="text"
                                    readOnly
                                    value={generatedShareUrl}
                                    className="flex-1 px-3 py-2 text-[10px] font-mono bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded text-slate-600 dark:text-slate-300 outline-none select-all"
                                />
                                <button
                                    onClick={() => {
                                        navigator.clipboard.writeText(generatedShareUrl);
                                        toast.success('Share link copied!');
                                    }}
                                    className={`px-3 py-2 text-xs font-bold text-white rounded flex items-center space-x-1 hover:opacity-90 active:scale-95 transition-all cursor-pointer border-none ${activeTheme.primaryBg} ${activeTheme.shadowClass}`}
                                >
                                    <FiCopy className="w-3.5 h-3.5" />
                                    <span>Copy</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </header>
    );
};

